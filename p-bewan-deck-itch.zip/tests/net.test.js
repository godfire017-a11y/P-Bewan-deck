import { Lobby, sanitizeInput } from '../server/room.js';
let pass = 0, fail = 0; const ok = (c, m) => { if (c) pass++; else { fail++; console.log('GAGAL:', m); } };
const mk = () => { const s = { msgs: [], send(x) { this.msgs.push(JSON.parse(x)); } }; return s; };
const L = new Lobby(); const A = mk(), B = mk(), C = mk();
const r1 = L.quick(A, { char: 'ZUKI', weapon: 'Katana' }, 'crimsonDojo'); const r2 = L.quick(B, { char: 'TITAN', weapon: 'BUKAN-SENJATA' });
ok(r1 === r2, 'quick match mempertemukan dua pemain'); ok(A.msgs.some((m) => m.t === 'start') && B.msgs.some((m) => m.t === 'start'), 'kedua klien menerima start');
ok(r1.picks[1].weapon === 'Greatsword', 'senjata tidak valid dikoreksi server');
const room = r1; for (let i = 0; i < 400; i++) { room.onMessage(A, { t: 'input', i: { x: 1, light: i % 20 === 0, hack: true, dmg: 99999 } }); room.onMessage(B, { t: 'input', i: { x: -1, guard: true } }); L.tick(); }
const st = A.msgs.filter((m) => m.t === 'state'); ok(st.length > 100, 'snapshot dikirim ~30Hz'); const last = st[st.length - 1].s;
ok(last.f[0].hp <= last.f[0].maxHp && last.f[1].hp <= last.f[1].maxHp, 'HP valid (server yang menghitung)');
const s = sanitizeInput({ x: 50, light: 1, evil: true }); ok(s.x === 1 && s.light === true && !('evil' in s), 'input disanitasi');
// disconnect + reconnect
room.leave(B); ok(A.msgs.some((m) => m.t === 'opponentDisconnected'), 'indikator disconnect'); const B2 = mk(); ok(room.reconnect(B2, 1) && room.disc === null, 'reconnect dalam jendela');
// disconnect lewat batas -> server menetapkan hasil
room.leave(B2); room.tick(Date.now() + 16000); ok(room.sim.result && room.sim.result.winner === 0 && room.sim.result.reason === 'surrender', 'disconnect >15 dtk = kalah');
// surrender oleh server
const L2 = new Lobby(), P = mk(), Q = mk(); const r = L2.create(P, { char: 'ZUKI' }); L2.joinCode(Q, r.code, { char: 'STARK' }); r.onMessage(P, { t: 'surrender' }); ok(r.sim.result.winner === 1, 'surrender ditetapkan server');
r.onMessage(P, { t: 'rematch' }); r.onMessage(Q, { t: 'rematch' }); ok(r.sim.round.state === 'intro' && r.sim.round.no === 1, 'rematch');
L2.joinCode(mk(), 'ZZZZ', {}); ok(true, 'kode salah tidak crash');
console.log(`${pass} lulus, ${fail} gagal (simulasi socket; BUKAN uji dua perangkat nyata)`); process.exit(fail ? 1 : 0);
