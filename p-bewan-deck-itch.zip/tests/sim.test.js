import { CHARACTERS, WEAPONS, SKILLS, STAGES, STAT_KEYS, deriveStats } from '../src/data/data.js';
import { createSim, step, surrender, EMPTY_INPUT, buildMoveset, listCombos } from '../src/core/sim.js';
import { createAI, aiInput } from '../src/core/ai.js';
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('GAGAL:', m); } };

// 1. data
for (const [k, c] of Object.entries(CHARACTERS)) {
  ok(STAT_KEYS.reduce((a, s) => a + c.pts[s], 0) === 100, `${k} power budget harus 100`);
  ok(c.skills.length === 2 && SKILLS[c.ult] && c.passive, `${k} butuh 2 skill, ult, passive`);
  for (const w of c.weapons) ok(WEAPONS[w], `${k} senjata ${w} tidak ada`);
  for (const s of c.skills) ok(SKILLS[s], `skill ${s}`);
}
ok(Object.keys(CHARACTERS).length >= 6 && Object.keys(WEAPONS).filter((w) => !WEAPONS[w].extra).length >= 8 && Object.keys(STAGES).length >= 6, 'jumlah roster/senjata/arena');
for (const [w, d] of Object.entries(WEAPONS)) ok(SKILLS[d.skill] && listCombos('ZUKI', w).length > 5, `senjata ${w} skill/combo`);
// moveset berbeda per senjata
const sig = (w) => JSON.stringify(Object.values(buildMoveset('ZUKI', w).moves).map((m) => [m.s, m.r, Math.round(m.dmg), m.reach]));
const sigs = new Set(Object.keys(WEAPONS).map(sig)); ok(sigs.size === Object.keys(WEAPONS).length, 'moveset tiap senjata harus unik');

// 2. simulasi: semua kombinasi karakter x senjata (default) dengan AI vs AI
const NOFAIL = (sim) => sim.f.every((f) => [f.x, f.y, f.hp, f.stamina, f.meter].every(Number.isFinite) && Math.abs(f.x) <= sim.half + 0.01 && f.y >= -0.001);
function play(a, b, seed, styles = ['aggressive', 'aggressive'], maxTicks = 60 * 60 * 3 + 2000) {
  const sim = createSim({ p1: a, p2: b, stage: 'shadowTemple', seed });
  const A = [createAI(styles[0], 'hard', seed), createAI(styles[1], 'hard', seed + 1)];
  let bad = 0; const maxStun = [0, 0];
  for (let t = 0; t < maxTicks && sim.round.state !== 'matchEnd'; t++) {
    const inputs = [aiInput(sim, 0, A[0]), aiInput(sim, 1, A[1])];
    step(sim, inputs); if (!NOFAIL(sim)) bad++;
    for (const f of sim.f) if (f.state === 'hitstun') maxStun[f.idx] = Math.max(maxStun[f.idx], f.t);
  }
  return { sim, bad, maxStun };
}
const keys = Object.keys(CHARACTERS); const wins = {}; keys.forEach((k) => (wins[k] = [0, 0])); let unfinished = 0, bads = 0, longStun = 0, games = 0, maxRounds = 0;
for (const a of keys) for (const b of keys) { if (a === b) continue; for (let s = 1; s <= 6; s++) {
  const r = play({ char: a, weapon: CHARACTERS[a].defaultWeapon }, { char: b, weapon: CHARACTERS[b].defaultWeapon }, s * 31 + a.length);
  games++; if (r.sim.round.state !== 'matchEnd') unfinished++; bads += r.bad; maxRounds = Math.max(maxRounds, r.sim.round.no);
  if (Math.max(...r.maxStun) > 140) longStun++;
  if (r.sim.result) { wins[r.sim.result.winner === 0 ? a : b][0]++; wins[r.sim.result.winner === 0 ? b : a][1]++; } } }
ok(unfinished === 0, `semua match harus selesai (belum selesai: ${unfinished})`);
ok(bads === 0, `state NaN/di luar arena: ${bads}`);
ok(maxRounds <= 3, 'maksimal 3 ronde');
ok(longStun === 0, `tidak boleh ada stun-lock panjang (${longStun})`);
console.log(`\nWin rate (AI vs AI, ${games} match, senjata default):`);
for (const k of keys) { const [w, l] = wins[k]; console.log(' ', k.padEnd(6), `${w}-${l}`, (100 * w / (w + l || 1)).toFixed(0) + '%'); }
const rates = keys.map((k) => wins[k][0] / (wins[k][0] + wins[k][1] || 1)); ok(Math.max(...rates) < 0.8 && Math.min(...rates) > 0.2, 'balance: tidak ada karakter yang >80% atau <20%');

// 3. semua senjata pada semua karakter yang mendukung berfungsi
let wpnGames = 0; const wpnWins = {};
for (const [ck, c] of Object.entries(CHARACTERS)) for (const w of c.weapons) { const r = play({ char: ck, weapon: w }, { char: 'ZUKI', weapon: 'Longsword' }, 99); wpnGames++; ok(r.sim.round.state === 'matchEnd' && r.bad === 0, `${ck}+${w} tidak selesai/bermasalah`); (wpnWins[w] ||= [0, 0])[r.sim.result && r.sim.result.winner === 0 ? 0 : 1]++; }
console.log('\nSenjata diuji pada', wpnGames, 'kombinasi karakter+senjata.');

// 4. surrender, 3 ronde, sudden death, dodge/parry/guard dasar
{ const sim = createSim({ p1: { char: 'ZUKI', weapon: 'Longsword' }, p2: { char: 'TITAN', weapon: 'Greatsword' }, seed: 5 }); for (let i = 0; i < 120; i++) step(sim, [EMPTY_INPUT, EMPTY_INPUT]); surrender(sim, 0); ok(sim.result.winner === 1 && sim.result.reason === 'surrender', 'surrender'); }
{ // timeout: sama-sama diam, HP sama -> sudden death -> tetap ada pemenang
  const sim = createSim({ p1: { char: 'ZUKI', weapon: 'Longsword' }, p2: { char: 'ZUKI', weapon: 'Longsword' }, seed: 3 }); let n = 0;
  while (sim.round.state !== 'matchEnd' && n++ < 60 * 400) step(sim, [EMPTY_INPUT, EMPTY_INPUT]);
  ok(sim.round.state === 'matchEnd' && sim.round.no <= 3, 'diam saja: match harus selesai <=3 ronde'); }
{ // hit nyata: jarak jauh tidak kena, jarak dekat kena
  const mk = (dx) => { const s = createSim({ p1: { char: 'ZUKI', weapon: 'Longsword' }, p2: { char: 'ZUKI', weapon: 'Longsword' }, seed: 1 }); s.round.state = 'fight'; s.f[1].x = s.f[0].x + dx; return s; };
  for (const [dx, expect] of [[5, false], [1.3, true]]) { const s = mk(dx); for (let i = 0; i < 40; i++) step(s, [i === 0 ? { ...EMPTY_INPUT, light: true } : EMPTY_INPUT, EMPTY_INPUT]); ok((s.f[1].hp < s.f[1].maxHp) === expect, `jangkauan: dx=${dx} hit=${expect}`); }
  // guard berdiri mengurangi damage, serangan rendah menembus guard berdiri
  const g = mk(1.3); for (let i = 0; i < 40; i++) step(g, [i === 0 ? { ...EMPTY_INPUT, light: true } : EMPTY_INPUT, { ...EMPTY_INPUT, guard: true }]); ok(g.f[1].hp > g.f[1].maxHp * 0.97 && g.f[1].stats.blocks + g.f[1].stats.parries >= 1, 'guard/parry bekerja');
  const lo = mk(1.3); for (let i = 0; i < 60; i++) step(lo, [i === 20 ? { ...EMPTY_INPUT, light: true, down: true } : EMPTY_INPUT, { ...EMPTY_INPUT, guard: true }]); ok(lo.f[1].hp < lo.f[1].maxHp * 0.97, 'serangan rendah menembus guard berdiri');
  const d = mk(1.3); for (let i = 0; i < 40; i++) step(d, [i === 0 ? { ...EMPTY_INPUT, light: true } : EMPTY_INPUT, i === 1 ? { ...EMPTY_INPUT, dodge: true, x: 1 } : EMPTY_INPUT]); ok(d.f[1].stats.dodges >= 0, 'dodge tidak crash');
  // bow: jauh proyektil mengenai, dekat lemah
  const b = createSim({ p1: { char: 'TONY', weapon: 'Bow' }, p2: { char: 'TITAN', weapon: 'Greatsword' }, seed: 2 }); b.round.state = 'fight'; b.f[1].x = 6; for (let i = 0; i < 90; i++) step(b, [i === 0 ? { ...EMPTY_INPUT, light: true } : EMPTY_INPUT, EMPTY_INPUT]); ok(b.f[1].hp < b.f[1].maxHp, 'Bow mengenai dari jauh'); }
console.log(`\n${pass} lulus, ${fail} gagal`); process.exit(fail ? 1 : 0);
