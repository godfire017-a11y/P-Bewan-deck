// ROOM: logika multiplayer authoritative, TANPA ketergantungan jaringan (socket = objek {send(str), id}).
// Server menjalankan sim sendiri; klien hanya mengirim INPUT. Damage/HP/timer/hasil ditentukan di sini.
import { createSim, step, snapshot, surrender, EMPTY_INPUT } from '../src/core/sim.js';
import { CHARACTERS } from '../src/data/data.js';

const KEYS = ['light', 'heavy', 'guard', 'dodge', 'dash', 's1', 's2', 'ws', 'ult', 'up', 'down'];
export function sanitizeInput(i) {                       // jangan percaya klien: paksa tipe dan rentang
  const o = Object.assign({}, EMPTY_INPUT); if (!i || typeof i !== 'object') return o;
  o.x = Math.max(-1, Math.min(1, Number(i.x) || 0)); for (const k of KEYS) o[k] = !!i[k]; return o;
}
export function sanitizePick(p) {
  const c = p && CHARACTERS[p.char] ? p.char : 'ZUKI'; const w = CHARACTERS[c].weapons.includes(p && p.weapon) ? p.weapon : CHARACTERS[c].defaultWeapon; return { char: c, weapon: w };
}
const STAGE_KEYS = ['shadowTemple', 'crimsonDojo', 'frozenRuins', 'emberFortress', 'moonlitGarden', 'stormArena'];
export class Room {
  constructor(code, seed = (Math.random() * 1e9) | 0) { this.code = code; this.seed = seed; this.players = [null, null]; this.picks = [null, null]; this.sim = null; this.inputs = [EMPTY_INPUT, EMPTY_INPUT]; this.evBuf = []; this.stage = 'shadowTemple'; this.rematch = [false, false]; this.timer = null; this.lastSeen = [0, 0]; this.tickN = 0; }
  join(sock, pick, stage) {
    const i = this.players[0] ? (this.players[1] ? -1 : 1) : 0; if (i < 0) return -1;
    this.players[i] = sock; this.picks[i] = sanitizePick(pick); this.lastSeen[i] = Date.now(); if (i === 0 && STAGE_KEYS.includes(stage)) this.stage = stage;
    sock.send(JSON.stringify({ t: 'joined', idx: i, code: this.code })); if (this.players[0] && this.players[1]) this.start(); return i;
  }
  start() {
    this.sim = createSim({ p1: this.picks[0], p2: this.picks[1], stage: this.stage, seed: this.seed }); this.rematch = [false, false]; this.inputs = [EMPTY_INPUT, EMPTY_INPUT];
    this.broadcast({ t: 'start', cfg: { p1: this.picks[0], p2: this.picks[1], stage: this.stage } });
  }
  broadcast(m) { const s = JSON.stringify(m); for (const p of this.players) if (p) try { p.send(s); } catch (e) {} }
  onMessage(sock, m) {
    const i = this.players.indexOf(sock); if (i < 0) return; this.lastSeen[i] = Date.now();
    if (m.t === 'input') this.inputs[i] = sanitizeInput(m.i);
    else if (m.t === 'surrender' && this.sim && this.sim.round.state !== 'matchEnd') surrender(this.sim, i);       // server menetapkan hasil
    else if (m.t === 'rematch' && this.sim && this.sim.round.state === 'matchEnd') { this.rematch[i] = true; if (this.rematch[0] && this.rematch[1]) { this.seed++; this.start(); } else this.broadcast({ t: 'rematchWait', idx: i }); }
    else if (m.t === 'ping') sock.send(JSON.stringify({ t: 'pong', c: m.c }));
  }
  leave(sock) {
    const i = this.players.indexOf(sock); if (i < 0) return; this.players[i] = null;
    if (this.sim && this.sim.round.state !== 'matchEnd') { this.disc = { idx: i, at: Date.now() }; this.broadcast({ t: 'opponentDisconnected', grace: 15 }); }   // jendela reconnect 15 dtk
  }
  reconnect(sock, i) { if (this.disc && this.disc.idx === i && !this.players[i]) { this.players[i] = sock; this.disc = null; sock.send(JSON.stringify({ t: 'joined', idx: i, code: this.code, resume: true })); this.broadcast({ t: 'opponentReconnected' }); return true; } return false; }
  tick(now = Date.now()) {
    if (!this.sim) return;
    if (this.disc && now - this.disc.at > 15000 && this.sim.round.state !== 'matchEnd') { surrender(this.sim, this.disc.idx); this.disc = null; }   // kalah karena disconnect
    if (!this.disc) step(this.sim, this.inputs);                                                                                                         // jeda saat menunggu reconnect
    this.evBuf.push(...this.sim.events); this.tickN++;
    if (this.tickN % 2 === 0) { const s = snapshot(this.sim); s.ev = this.evBuf; this.evBuf = []; this.broadcast({ t: 'state', s }); }   // 30 Hz dengan event terakumulasi
  }
  empty() { return !this.players[0] && !this.players[1]; }
}
export class Lobby {
  constructor() { this.rooms = new Map(); this.queue = null; }
  code() { let c; do { c = Math.random().toString(36).slice(2, 6).toUpperCase(); } while (this.rooms.has(c)); return c; }
  create(sock, pick, stage) { const r = new Room(this.code()); this.rooms.set(r.code, r); r.join(sock, pick, stage); return r; }
  joinCode(sock, code, pick) { const r = this.rooms.get(String(code).toUpperCase()); if (!r) { sock.send(JSON.stringify({ t: 'error', msg: 'Kode room tidak ditemukan' })); return null; } if (r.join(sock, pick) < 0) { sock.send(JSON.stringify({ t: 'error', msg: 'Room penuh' })); return null; } return r; }
  quick(sock, pick, stage) {
    if (this.queue && this.queue.players[0] && !this.queue.players[1]) { const r = this.queue; this.queue = null; r.join(sock, pick); return r; }
    const r = this.create(sock, pick, stage); this.queue = r; return r;
  }
  tick() { for (const [c, r] of this.rooms) { r.tick(); if (r.empty() && !(r.disc)) { this.rooms.delete(c); if (this.queue === r) this.queue = null; } } }
}
