// Jalankan: npm install ws && node server/server.js   (port 8080, ubah dengan PORT=xxxx)
// Server ini HARUS di-host sendiri (VPS/Render/Fly/dll). File HTML saja tidak bisa menggantikan server online.
import { WebSocketServer } from 'ws';
import { Lobby } from './room.js';
const wss = new WebSocketServer({ port: Number(process.env.PORT) || 8080 }), lobby = new Lobby(), where = new WeakMap();
wss.on('connection', (ws) => {
  ws.id = Math.random().toString(36).slice(2); ws.alive = true; ws.on('pong', () => (ws.alive = true));
  ws.on('message', (d) => {
    let m; try { m = JSON.parse(d); } catch (e) { return; } if (!m || typeof m.t !== 'string' || d.length > 2048) return;
    const room = where.get(ws);
    if (m.t === 'quick') where.set(ws, lobby.quick(ws, m.pick, m.stage));
    else if (m.t === 'create') where.set(ws, lobby.create(ws, m.pick, m.stage));
    else if (m.t === 'join') { const r = lobby.joinCode(ws, m.code, m.pick); if (r) where.set(ws, r); }
    else if (room) room.onMessage(ws, m);
  });
  ws.on('close', () => { const r = where.get(ws); if (r) r.leave(ws); });
});
setInterval(() => lobby.tick(), 1000 / 60);
setInterval(() => wss.clients.forEach((c) => { if (!c.alive) return c.terminate(); c.alive = false; c.ping(); }), 10000);
console.log('P Bewan Deck server siap di port', process.env.PORT || 8080);
