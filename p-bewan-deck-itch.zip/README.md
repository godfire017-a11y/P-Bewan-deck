# P Bewan Deck

## Menjalankan game (lokal)
Library Three.js dimuat dari CDN, jadi perlu internet. Dari folder ini:
```
python3 -m http.server 8000      # atau: npx serve .
```
Buka `http://localhost:8000` (di HP: `http://IP-KOMPUTER:8000`, satu Wi-Fi). Jangan buka `index.html` langsung dari file:// (fetch aset diblokir).

## Tes otomatis (tanpa browser)
```
npm test                 # simulasi pertarungan + balance
node tests/net.test.js   # logika server dengan socket tiruan
```

## Server online
```
npm install ws
npm run server           # port 8080, ubah dengan PORT=9000
```
Server harus di-host sendiri. Di game: PvP > isi `ws://IP:8080` > Quick Match / Buat Room / Gabung (kode). HTTPS memerlukan `wss://`.

## Kontrol Android
Joystick kiri (kiri/kanan = gerak, atas = lompat, bawah = nunduk). Kanan: Light, Heavy, Guard, Dodge, Dash, S1, S2, WS (skill senjata), ULT. Tombol II = Pause (Combo, Give Up).
Kombinasi: Atas+Light = High, Bawah+Light = Low, Maju+Light = Forward, Mundur+Light = Back, Bawah+Heavy = Launcher, Dash+Light, Guard tepat waktu = Parry, Dodge tepat waktu = Perfect Dodge lalu Light = Counter. Bow: tahan Heavy untuk menarik tali.

## Keyboard
P1: A/D, W, S, J Light, K Heavy, L Guard, U Dodge, I Dash, 1/2 skill, 3 WS, 4 ULT. P2 (Local Versus): panah, `,` Light, `.` Heavy, `/` Guard, `;` Dodge, `'` Dash, `[` `]` skill, `\` WS, Enter ULT. Training: T mengganti perilaku dummy.

## Struktur
`src/data/data.js` (semua balance), `src/core/sim.js` (pertarungan), `src/core/ai.js`, `src/view/*` (Three.js, audio), `src/main.js` (UI/mode), `server/*` (multiplayer), `docs/LAPORAN.md` (audit, status, keterbatasan).

## Deploy ke itch.io (HTML5)
1. Zip SELURUH isi folder ini sehingga `index.html` ada di root zip (jangan zip folder induknya).
2. itch.io > Upload > "This file will be played in the browser", centang "Mobile friendly", pilih ukuran embed 1280x720 dan fullscreen.
3. Jika game gagal dimuat, layar error menampilkan nama/pesan/file/baris error asli, status tiap file modul (HTTP, content-type), dan tombol **Coba Lagi**. Kirim teks itu (tombol "Salin detail") bila perlu bantuan.

## Menghilangkan ketergantungan CDN (disarankan untuk rilis)
Default: game memuat Three.js r160 dari jsDelivr (cadangan unpkg). Untuk build offline-mandiri (Three.js + FBXLoader + GLTFLoader + SkeletonUtils + fflate digabung ke satu file), di komputer/Termux yang punya internet:
```
npm install three@0.160.0 esbuild
node scripts/build.mjs          # menghasilkan bundle/game.js
```
Lalu zip ulang folder (termasuk `bundle/`). `index.html` otomatis memakai `bundle/game.js` dan tidak memanggil CDN. Alternatif ringan: `sh scripts/vendor-three.sh` menaruh Three.js di `lib/three/`.

## Tes
`npm test` (simulasi + server tiruan), `npm run test:ui` (alur UI di Chromium; butuh puppeteer, memakai Three.js TIRUAN).
