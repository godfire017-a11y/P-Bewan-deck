Taruh three.js lokal di sini dengan: sh scripts/vendor-three.sh
