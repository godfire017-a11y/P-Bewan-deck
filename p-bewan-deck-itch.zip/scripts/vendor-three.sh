#!/bin/sh
# Jalankan SEKALI di komputer yang punya internet, dari folder proyek: sh scripts/vendor-three.sh
# Hasil: lib/three/ (dipakai otomatis oleh game, jadi tidak perlu CDN lagi / bisa offline).
set -e
npm pack three@0.160.0 >/dev/null && tar xzf three-0.160.0.tgz
mkdir -p lib/three/build lib/three/examples/jsm
cp package/build/three.module.js package/build/three.core.js lib/three/build/ 2>/dev/null || cp package/build/three.module.js lib/three/build/
for d in loaders utils curves libs; do cp -r package/examples/jsm/$d lib/three/examples/jsm/; done
rm -rf package three-0.160.0.tgz && echo "Selesai: lib/three siap."
