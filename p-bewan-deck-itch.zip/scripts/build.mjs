// Bundel game + Three.js + addon (FBXLoader, GLTFLoader, SkeletonUtils, fflate, dll.) menjadi SATU file: bundle/game.js
// Pemakaian (komputer/Termux dengan internet, sekali saja):
//   npm install three@0.160.0 esbuild      (jalankan di folder proyek)
//   node scripts/build.mjs
// Setelah itu index.html otomatis memakai bundle/game.js dan TIDAK lagi memuat CDN. Zip seluruh folder untuk itch.io.
import { createRequire } from 'module'; import fs from 'fs'; import path from 'path';
const root = path.resolve(new URL('..', import.meta.url).pathname), req = createRequire(root + '/'); let esbuild;
try { esbuild = req('esbuild'); } catch (e) { console.error('esbuild belum terpasang. Jalankan: npm install three@0.160.0 esbuild'); process.exit(1); }
let threeDir; try { threeDir = path.dirname(req.resolve('three/package.json')); } catch (e) { console.error('three belum terpasang. Jalankan: npm install three@0.160.0 esbuild'); process.exit(1); }
const ver = JSON.parse(fs.readFileSync(threeDir + '/package.json', 'utf8')).version; if (ver !== '0.160.0') console.warn('PERINGATAN: three ' + ver + ' (game diuji dengan API r160)');
fs.mkdirSync(root + '/bundle', { recursive: true });
const res = await esbuild.build({ entryPoints: [root + '/src/main.js'], bundle: true, format: 'esm', outfile: root + '/bundle/game.js', minify: true, target: ['es2020', 'chrome90'], logLevel: 'info', metafile: true,
  alias: { three: threeDir + '/build/three.module.js', 'three/addons': threeDir + '/examples/jsm' } });
const out = Object.entries(res.metafile.outputs)[0]; console.log('OK bundle/game.js', (out[1].bytes / 1024 / 1024).toFixed(2), 'MB');
const bad = Object.keys(res.metafile.inputs).filter((f) => /^https?:/.test(f)); if (bad.length) { console.error('Masih ada dependensi eksternal:', bad); process.exit(1); }
