// DATA TERPUSAT: semua balance ada di sini. Ubah angka di file ini tanpa menyentuh sim.js.
// Satuan: dunia = meter, waktu = frame simulasi 60 Hz.
export const TICK = 60;

/* ---------------------------------------------------------------- KARAKTER
   Power budget: 6 atribut, total WAJIB 100 poin (dicek di tests/sim.test.js). */
export const STAT_KEYS = ['hp', 'atk', 'spd', 'def', 'stun', 'mob'];
export const CHARACTERS = {
  ZUKI: { name: 'ZUKI', title: 'Balanced Fighter', desc: 'Petarung serba bisa. Tidak ada kelemahan besar, tidak ada keunggulan ekstrem.',
    pts: { hp: 17, atk: 17, spd: 16, def: 17, stun: 16, mob: 17 }, weapons: ['Longsword', 'Katana', 'Spear', 'War Axe', 'Twin Blades'], defaultWeapon: 'Longsword',
    skills: ['crescent', 'guardBreak'], ult: 'zukiUlt', passive: { id: 'Second Wind', desc: 'HP di bawah 30%: +10% kecepatan serang.' }, color: 0x59b8ff, asset: 'bull_knight', doubleJump: false },
  MASHU: { name: 'MASHU', title: 'Glass Cannon', desc: 'Damage mentah tertinggi, tetapi pertahanan rapuh. Wajib agresif.',
    pts: { hp: 14, atk: 26, spd: 18, def: 8, stun: 14, mob: 20 }, weapons: ['Greatsword', 'War Axe', 'Longsword', 'Dual Daggers', 'Katana'], defaultWeapon: 'War Axe',
    skills: ['bloodRush', 'berserk'], ult: 'mashuUlt', passive: { id: 'Bloodlust', desc: 'Kombo 3+ hit memberi +5 meter ultimate.' }, color: 0xff5a3d, asset: 'orc_warrior', doubleJump: false },
  TITAN: { name: 'TITAN', title: 'Immovable Wall', desc: 'HP dan poise sangat tinggi, serangan berat. Lambat dan mudah dihindari.',
    pts: { hp: 28, atk: 20, spd: 8, def: 22, stun: 14, mob: 8 }, weapons: ['Greatsword', 'War Axe', 'Spear', 'Longsword'], defaultWeapon: 'Greatsword',
    skills: ['quake', 'stoneSkin'], ult: 'titanUlt', passive: { id: 'Unflinching', desc: 'Poise ekstra: serangan ringan tidak menghentikan serangan berat.' }, color: 0xc8a050, asset: 'golem', doubleJump: false },
  STARK: { name: 'STARK', title: 'Phantom Blade', desc: 'Mobilitas dan evasion terbaik. Damage kecil, sulit dimainkan.',
    pts: { hp: 14, atk: 18, spd: 22, def: 10, stun: 12, mob: 24 }, weapons: ['Dual Daggers', 'Katana', 'Twin Blades', 'Longsword'], defaultWeapon: 'Dual Daggers',
    skills: ['shadowStep', 'fanKnives'], ult: 'starkUlt', passive: { id: 'Ghost Step', desc: 'Perfect dodge memberi +25% kecepatan gerak 2 detik. Double jump.' }, color: 0xb070ff, asset: 'phantom_assassin', doubleJump: true },
  APCB: { name: 'APCB', title: 'Hex Controller', desc: 'Kontrol: slow dan stun. Damage mentah rendah.',
    pts: { hp: 16, atk: 14, spd: 14, def: 16, stun: 26, mob: 14 }, weapons: ['Spear', 'Dual Daggers', 'Twin Blades', 'Longsword'], defaultWeapon: 'Spear',
    skills: ['hexTrap', 'chainBind'], ult: 'apcbUlt', passive: { id: 'Hex Mark', desc: 'Lawan yang terkena slow menerima +8% damage.' }, color: 0xd04070, asset: 'vampire', doubleJump: false },
  TONY: { name: 'TONY', title: 'Marksman', desc: 'Tekanan jarak jauh dan counter. Lemah jika lawan berhasil mendekat.',
    pts: { hp: 15, atk: 18, spd: 18, def: 11, stun: 18, mob: 20 }, weapons: ['Bow', 'Dual Daggers', 'Spear', 'Longsword'], defaultWeapon: 'Bow',
    skills: ['piercingShot', 'backflip'], ult: 'tonyUlt', passive: { id: 'Eagle Eye', desc: 'Damage proyektil naik sesuai jarak (maks +25%).' }, color: 0x6fe08a, asset: 'archer', doubleJump: false },
};
// rumus turunan dari poin atribut (satu tempat untuk tuning global)
export function deriveStats(c) {
  const p = c.pts;
  return {
    maxHp: 600 + p.hp * 20,
    atkMul: 0.6 + p.atk * 0.035,
    speedMul: 0.8 + p.spd * 0.02,          // pembagi frame startup/recovery
    walk: 1.6 + p.mob * 0.05,              // m/s
    dashDist: 1.5 + p.mob * 0.05,
    dmgTaken: 1 - p.def * 0.012,
    poise: 20 + p.def * 3 + p.hp,
    stunMul: 0.6 + p.stun * 0.035,
    dodgeI: 10 + Math.floor(p.mob * 0.2),  // frame kebal saat dodge
    width: 0.8,
    height: 1.8,
  };
}

/* ---------------------------------------------------------------- TEMPLATE GERAKAN
   s=startup a=active r=recovery (frame), d=pengali damage, lv=level (high/mid/low), kb=knockback, hs=hitstun, bs=blockstun,
   y=[bawah,atas] hitbox (m dari kaki), lunge=maju (m), launch/air/spike khusus. */
export const MOVE_TEMPLATES = {
  L1:     { s: 6,  a: 3, r: 10, d: 1.0, lv: 'mid',  kb: 1.0, hs: 16, bs: 10, y: [0.5, 1.5], lunge: 0.2 },
  L2:     { s: 7,  a: 3, r: 11, d: 1.1, lv: 'mid',  kb: 1.2, hs: 17, bs: 11, y: [0.5, 1.5], lunge: 0.25 },
  L3:     { s: 9,  a: 4, r: 17, d: 1.5, lv: 'mid',  kb: 3.0, hs: 26, bs: 14, y: [0.4, 1.6], lunge: 0.4, knock: true },
  H:      { s: 16, a: 4, r: 24, d: 2.2, lv: 'mid',  kb: 4.5, hs: 30, bs: 18, y: [0.3, 1.7], lunge: 0.35, armor: 1, knock: true },
  HIGH:   { s: 9,  a: 3, r: 14, d: 1.1, lv: 'high', kb: 1.4, hs: 18, bs: 11, y: [1.2, 2.0] },
  LOW:    { s: 10, a: 3, r: 16, d: 1.0, lv: 'low',  kb: 1.0, hs: 20, bs: 12, y: [0.0, 0.5] },
  FWD:    { s: 12, a: 4, r: 18, d: 1.5, lv: 'mid',  kb: 2.5, hs: 24, bs: 14, y: [0.4, 1.6], lunge: 1.0 },
  BACK:   { s: 8,  a: 3, r: 14, d: 0.9, lv: 'mid',  kb: 1.5, hs: 16, bs: 10, y: [0.5, 1.5], back: 0.5 },
  LAUNCH: { s: 14, a: 4, r: 26, d: 1.3, lv: 'low',  kb: 0.5, hs: 40, bs: 16, y: [0.0, 1.0], launch: 7.0 },
  CROUCH: { s: 6,  a: 3, r: 10, d: 0.9, lv: 'low',  kb: 0.8, hs: 14, bs: 9,  y: [0.0, 0.7] },
  AIR:    { s: 6,  a: 7, r: 8,  d: 1.1, lv: 'high', kb: 1.2, hs: 16, bs: 10, y: [0.2, 1.6], air: true },
  AIRH:   { s: 10, a: 5, r: 10, d: 1.6, lv: 'high', kb: 2.0, hs: 24, bs: 14, y: [0.0, 1.5], air: true, spike: true },
  DASH:   { s: 8,  a: 5, r: 16, d: 1.4, lv: 'mid',  kb: 3.0, hs: 24, bs: 14, y: [0.4, 1.6], lunge: 1.6 },
  COUNTER:{ s: 4,  a: 4, r: 14, d: 2.0, lv: 'mid',  kb: 4.0, hs: 34, bs: 16, y: [0.3, 1.7], lunge: 0.6, knock: true },
};

/* ---------------------------------------------------------------- SENJATA (8 wajib + 1 tambahan dari aset)
   reach (m), dmg (pengali), spd (pembagi frame), rec (pengali recovery), stun (pengali hitstun),
   combo: rangkaian Light -> id template; heavy: template Heavy. o: override per template.
   model: nama GLB bila ada aset (null = model prosedural). */
export const WEAPONS = {
  Longsword: { reach: 1.45, dmg: 1.0, spd: 1.0, rec: 1.0, stun: 1.0, arc: 'horizontal', model: null, hand: 'R', grip: 'one',
    desc: 'Seimbang. Kombo stabil dan jangkauan menengah.', combo: { light: ['L1', 'L2', 'L3'], heavy: 'H' }, skill: 'wsLongsword', trail: 0xdfe8ff },
  'Dual Daggers': { reach: 0.95, dmg: 1.05, spd: 1.45, rec: 0.75, stun: 0.7, arc: 'cross', model: null, hand: 'LR', grip: 'dual',
    desc: 'Sangat cepat, jangkauan pendek. Serang bertubi-tubi.', combo: { light: ['L1', 'L2', 'L1', 'L2', 'L3'], heavy: 'FWD' }, skill: 'wsDaggers', trail: 0xb0ffb0,
    o: { L1: { s: 4, r: 7 }, L2: { s: 4, r: 7 } } },
  Katana: { reach: 1.6, dmg: 0.95, spd: 1.12, rec: 1.0, stun: 0.9, arc: 'diagonal', model: null, hand: 'R', grip: 'two',
    desc: 'Tebasan presisi. Counter kuat setelah parry.', combo: { light: ['L1', 'HIGH', 'L3'], heavy: 'H' }, skill: 'wsKatana', trail: 0xffffff,
    o: { COUNTER: { d: 2.6 } } },
  Greatsword: { reach: 1.9, dmg: 1.6, spd: 0.78, rec: 1.3, stun: 1.4, arc: 'overhead', model: 'voidfang_greatsword', hand: 'R', grip: 'two',
    desc: 'Lambat tetapi menghancurkan. Jangkauan luas, recovery panjang.', combo: { light: ['L1', 'L3'], heavy: 'H' }, skill: 'wsGreatsword', trail: 0x9a6bff,
    o: { H: { s: 22, d: 2.8, kb: 6.5 } } },
  Spear: { reach: 2.25, dmg: 0.9, spd: 0.95, rec: 1.0, stun: 1.0, arc: 'thrust', model: null, hand: 'R', grip: 'two',
    desc: 'Jangkauan terpanjang. Lemah ketika lawan menempel.', combo: { light: ['L1', 'FWD', 'L3'], heavy: 'LAUNCH' }, skill: 'wsSpear', trail: 0xffe08a, minReach: 0.7,
    o: { L1: { y: [0.6, 1.3] }, FWD: { lunge: 1.4 } } },
  'War Axe': { reach: 1.35, dmg: 1.35, spd: 0.82, rec: 1.2, stun: 1.2, arc: 'overhead', model: 'fantasy_axe_and_shield', hand: 'R', grip: 'one',
    desc: 'Pukulan berat, menembus sebagian guard.', combo: { light: ['L1', 'L3'], heavy: 'H' }, skill: 'wsAxe', trail: 0xff9a5a, o: { H: { guardPierce: 0.5 } } },
  Bow: { reach: 9.0, dmg: 0.72, spd: 0.9, rec: 1.0, stun: 0.8, arc: 'projectile', model: 'bow', hand: 'L', grip: 'bow', ranged: true,
    desc: 'Serang dari jauh. Tarik tali lebih lama = lebih kuat. Lemah di jarak dekat.', combo: { light: ['L1'], heavy: 'H' }, skill: 'wsBow', trail: 0xd8ffb0, minReach: 2.2, melee: { reach: 0.9, dmg: 0.5 } },
  'Twin Blades': { reach: 1.2, dmg: 1.0, spd: 1.25, rec: 0.85, stun: 0.85, arc: 'spin', model: null, hand: 'LR', grip: 'dual',
    desc: 'Putaran cepat, kombo panjang dan fleksibel.', combo: { light: ['L1', 'L2', 'L1', 'L3'], heavy: 'FWD' }, skill: 'wsTwin', trail: 0x7fe9ff },
  Scythe: { reach: 1.85, dmg: 1.2, spd: 0.8, rec: 1.15, stun: 1.0, arc: 'sweep', model: 'soul_reaper_scythe__dark_fantasy_weapon', hand: 'R', grip: 'two', extra: true,
    desc: 'Tebasan melebar. (Belum dipasang ke karakter mana pun.)', combo: { light: ['L1', 'L3'], heavy: 'H' }, skill: 'wsLongsword', trail: 0xb9ff8a },
};

/* ---------------------------------------------------------------- SKILL
   kind: projectile | dashSlash | teleport | area | counterStance | shield | stunAttack | launcher | buff | trap */
export const SKILLS = {
  crescent:   { name: 'Crescent Slash', kind: 'projectile', cd: 360, s: 14, rec: 18, dmg: 90, speed: 9, life: 70, stun: 14, color: 0x59b8ff, desc: 'Gelombang tebasan jarak menengah.' },
  guardBreak: { name: 'Guard Breaker', kind: 'stunAttack', cd: 540, s: 18, rec: 22, dmg: 60, reach: 1.6, stun: 50, guardBreak: true, color: 0xffd060, desc: 'Menembus guard dan membuat lawan terhuyung.' },
  zukiUlt:    { name: 'Azure Dance', kind: 'dashSlash', ult: true, s: 12, rec: 30, dmg: 320, dist: 4.5, hits: 4, color: 0x59b8ff, desc: 'Dash 4 tebasan beruntun.' },
  bloodRush:  { name: 'Blood Rush', kind: 'dashSlash', cd: 420, s: 10, rec: 26, dmg: 110, dist: 3.2, hits: 1, color: 0xff5a3d, desc: 'Menerjang. Rapuh jika meleset.' },
  berserk:    { name: 'Berserk', kind: 'buff', cd: 900, s: 8, rec: 14, frames: 300, atk: 1.3, def: 1.15, color: 0xff3030, desc: '5 dtk: +30% damage, +15% damage diterima.' },
  mashuUlt:   { name: 'Crimson Execution', kind: 'launcher', ult: true, s: 20, rec: 40, dmg: 360, color: 0xff2030, desc: 'Launcher + hantaman jatuh.' },
  quake:      { name: 'Quake Stomp', kind: 'area', cd: 600, s: 24, rec: 30, dmg: 85, radius: 2.8, stun: 36, groundOnly: true, color: 0xc8a050, desc: 'Hentakan area. Bisa dilompati.' },
  stoneSkin:  { name: 'Stone Skin', kind: 'shield', cd: 840, s: 6, rec: 10, frames: 240, absorb: 150, color: 0xaaaaaa, desc: 'Perisai 150 damage, 4 dtk.' },
  titanUlt:   { name: 'Mountain Fall', kind: 'area', ult: true, s: 40, rec: 50, dmg: 330, radius: 3.6, stun: 60, groundOnly: true, color: 0xffb040, desc: 'Hantaman raksasa. Tanda bahaya panjang.' },
  shadowStep: { name: 'Shadow Step', kind: 'teleport', cd: 480, s: 6, rec: 10, dist: 2.4, color: 0xb070ff, desc: 'Teleport ke belakang lawan.' },
  fanKnives:  { name: 'Fan of Knives', kind: 'projectile', cd: 420, s: 10, rec: 16, dmg: 40, speed: 12, life: 40, count: 3, spread: 0.35, color: 0xd9a0ff, desc: '3 pisau melebar.' },
  starkUlt:   { name: 'Phantom Flurry', kind: 'dashSlash', ult: true, s: 8, rec: 24, dmg: 300, dist: 5.5, hits: 6, color: 0xd0a0ff, desc: '6 tebasan sangat cepat.' },
  hexTrap:    { name: 'Hex Trap', kind: 'trap', cd: 600, s: 10, rec: 14, life: 480, slow: 0.5, slowFrames: 150, dmg: 30, color: 0xd04070, desc: 'Jebakan: lawan terkena slow.' },
  chainBind:  { name: 'Chain Bind', kind: 'stunAttack', cd: 780, s: 20, rec: 26, dmg: 40, reach: 3.2, stun: 55, color: 0xff7090, desc: 'Rantai jarak jauh, membuat lawan terpaku.' },
  apcbUlt:    { name: 'Crimson Prison', kind: 'area', ult: true, s: 22, rec: 40, dmg: 150, radius: 4.0, stun: 80, slow: 0.6, slowFrames: 240, color: 0xff3060, desc: 'Stun lama + slow, tetapi damage kecil.' },
  piercingShot:{ name: 'Piercing Shot', kind: 'projectile', cd: 480, s: 20, rec: 22, dmg: 120, speed: 16, life: 60, stun: 20, pierceGuard: 0.5, color: 0x6fe08a, desc: 'Panah cepat yang menembus guard sebagian.' },
  backflip:   { name: 'Backflip Shot', kind: 'teleport', cd: 420, s: 8, rec: 12, dist: -3.0, shoot: true, dmg: 60, speed: 14, life: 50, stun: 10, color: 0x9affb0, desc: 'Lompat mundur sambil menembak.' },
  tonyUlt:    { name: 'Rain of Arrows', kind: 'projectile', ult: true, s: 24, rec: 34, dmg: 55, speed: 13, life: 50, count: 6, spread: 0.6, color: 0x40ff80, desc: '6 panah menyebar.' },
  // skill khas senjata
  wsLongsword:{ name: 'Rising Cut', kind: 'launcher', cd: 480, s: 12, rec: 22, dmg: 70, color: 0xdfe8ff, desc: 'Tebasan naik.' },
  wsDaggers:  { name: 'Blade Flurry', kind: 'dashSlash', cd: 420, s: 6, rec: 14, dmg: 70, dist: 2.0, hits: 3, color: 0xb0ffb0, desc: 'Rentetan 3 tusukan.' },
  wsKatana:   { name: 'Iaido', kind: 'counterStance', cd: 600, s: 4, frames: 40, rec: 18, dmg: 160, color: 0xffffff, desc: 'Posisi counter: tebasan balasan.' },
  wsGreatsword:{ name: 'Void Cleave', kind: 'area', cd: 720, s: 26, rec: 30, dmg: 140, radius: 2.4, stun: 30, color: 0x9a6bff, desc: 'Sapuan area di depan.' },
  wsSpear:    { name: 'Lunge Thrust', kind: 'dashSlash', cd: 480, s: 12, rec: 22, dmg: 90, dist: 2.6, hits: 1, color: 0xffe08a, desc: 'Tusukan menerjang.' },
  wsAxe:      { name: 'Skull Splitter', kind: 'stunAttack', cd: 660, s: 22, rec: 28, dmg: 100, reach: 1.5, stun: 40, color: 0xff9a5a, desc: 'Hantaman yang membuat lawan pusing.' },
  wsBow:      { name: 'Charged Volley', kind: 'projectile', cd: 540, s: 18, rec: 20, dmg: 50, speed: 14, life: 50, count: 3, spread: 0.2, color: 0xd8ffb0, desc: '3 panah cepat.' },
  wsTwin:     { name: 'Whirlwind', kind: 'area', cd: 480, s: 8, rec: 20, dmg: 75, radius: 1.8, stun: 18, color: 0x7fe9ff, desc: 'Putaran 360 derajat.' },
};

/* ---------------------------------------------------------------- ARENA */
export const STAGES = {
  shadowTemple:  { name: 'Shadow Temple', width: 11, sky: [0x2b3142, 0x1b1f2b, 0x0c0d12], fog: 0x1b1f2b, ground: 0x1a1d26, light: 0x8a96b4, rim: 0xaec4ff, particles: 'dust', music: 'minor', desc: 'Kuil kuno diselimuti kabut.' },
  crimsonDojo:   { name: 'Crimson Dojo', width: 10, sky: [0x5a1f26, 0x2c0f14, 0x120608], fog: 0x2c0f14, ground: 0x3a1a1a, light: 0xffc9a0, rim: 0xff6a3d, particles: 'petals', music: 'taiko', desc: 'Dojo merah dengan lentera.' },
  frozenRuins:   { name: 'Frozen Ruins', width: 11.5, sky: [0x7fb4d8, 0x3a6a8c, 0x14283a], fog: 0x3a6a8c, ground: 0x9fc4de, light: 0xdff0ff, rim: 0x8fd3ff, particles: 'snow', music: 'airy', desc: 'Reruntuhan es yang terang.' },
  emberFortress: { name: 'Ember Fortress', width: 10.5, sky: [0x6a2a10, 0x301208, 0x120604], fog: 0x301208, ground: 0x2a1812, light: 0xffa060, rim: 0xff8a3d, particles: 'embers', music: 'drums', desc: 'Benteng di tepi lava.' },
  moonlitGarden: { name: 'Moonlit Garden', width: 11, sky: [0x20386a, 0x142446, 0x0a1224], fog: 0x142446, ground: 0x1f3a2c, light: 0xb0c8ff, rim: 0x90e0ff, particles: 'fireflies', music: 'calm', desc: 'Taman di bawah bulan.' },
  stormArena:    { name: 'Storm Arena', width: 10, sky: [0x3a3f4a, 0x23262e, 0x0e1014], fog: 0x23262e, ground: 0x2a2e36, light: 0xc0c8d8, rim: 0xffffff, particles: 'rain', music: 'storm', desc: 'Arena terbuka saat badai.' },
};

/* ---------------------------------------------------------------- AI & PvE */
export const AI_STYLES = {
  aggressive: { approach: 0.9, atkRate: 0.9, guard: 0.15, dodge: 0.1, parry: 0.05, react: 14, spacing: 1.1, skill: 0.5, label: 'Aggressive' },
  defensive:  { approach: 0.4, atkRate: 0.35, guard: 0.65, dodge: 0.2, parry: 0.15, react: 10, spacing: 1.8, skill: 0.3, label: 'Defensive' },
  counter:    { approach: 0.4, atkRate: 0.3, guard: 0.3, dodge: 0.3, parry: 0.45, react: 9, spacing: 1.6, skill: 0.3, label: 'Counter-focused' },
  ranged:     { approach: 0.1, atkRate: 0.7, guard: 0.2, dodge: 0.3, parry: 0.05, react: 14, spacing: 5.5, skill: 0.6, label: 'Ranged' },
  heavy:      { approach: 0.6, atkRate: 0.45, guard: 0.2, dodge: 0.05, parry: 0.05, react: 18, spacing: 1.7, skill: 0.4, label: 'Heavy attacker', preferHeavy: 0.7 },
  evasive:    { approach: 0.5, atkRate: 0.5, guard: 0.1, dodge: 0.6, parry: 0.1, react: 8, spacing: 2.2, skill: 0.4, label: 'Evasive' },
  boss:       { approach: 0.7, atkRate: 0.6, guard: 0.3, dodge: 0.25, parry: 0.2, react: 10, spacing: 1.8, skill: 0.6, label: 'Boss', phases: true },
};
export const DIFFICULTY = { easy: { reactAdd: 10, mistake: 0.35 }, normal: { reactAdd: 4, mistake: 0.18 }, hard: { reactAdd: 0, mistake: 0.06 } };
export const PVE_MODES = {
  story:    { name: 'Story Battles', desc: 'Lawan berurutan dengan gaya berbeda.', list: [['ZUKI', 'aggressive'], ['TONY', 'ranged'], ['APCB', 'counter'], ['STARK', 'evasive'], ['TITAN', 'heavy']] },
  survival: { name: 'Survival', desc: 'HP sisa terbawa ke lawan berikutnya (pulih 35% dari yang hilang). Bertahan selama mungkin.', carryHp: 0.35 },
  endless:  { name: 'Endless Waves', desc: 'Gelombang tanpa akhir, kesulitan naik.', scale: true },
  elite:    { name: 'Elite Challenge', desc: 'Satu lawan elit (AI hard, tanpa ultimate), best-of-3.', noUlt: true },
  boss:     { name: 'Boss Fight', desc: 'Boss dengan 3 fase; pelajari tanda bahayanya.', boss: 'TITAN' },
  daily:    { name: 'Daily Challenge', desc: 'Modifier acak berdasarkan tanggal.', daily: true },
};
export const MODIFIERS = {
  glass:   { name: 'Glass Cannon', desc: 'Damage kedua pihak x1.6, HP x0.7', dmg: 1.6, hp: 0.7 },
  nometer: { name: 'No Ultimate', desc: 'Ultimate dimatikan', noUlt: true },
  swift:   { name: 'Swift', desc: 'Kecepatan serang x1.2', spd: 1.2 },
  armor:   { name: 'Iron Skin', desc: 'Lawan menerima damage x0.8', enemyDef: 0.8 },
};

/* ---------------------------------------------------------------- ATURAN */
export const RULES = {
  rounds: 3, roundTime: 60, introFrames: 90, endFrames: 150, suddenDeathTime: 15,
  stamina: { max: 100, regen: 0.45, dodge: 25, dash: 18 },
  parry: { window: 6, cd: 50, stunFrames: 34, counterWindow: 40 },
  perfectDodge: { window: 6, counterWindow: 45, meter: 12 },
  guard: { chip: 0.1, staminaPerDmg: 0.12 },
  meter: { max: 100, onHit: 0.04, onHurt: 0.03, onBlock: 2 },   // onHit/onHurt = per damage
  // anti stun-lock
  combo: { scale: [1, 1, 1, 0.9, 0.8, 0.7, 0.6], maxHitsBeforeBreak: 7, breakInvuln: 40, ccImmunity: 120, maxStun: 80 },
  arenaPad: 0.5, minSeparation: 0.9, gravity: 26, jumpV: 9.5, bufferFrames: 10,
};
