// MAIN: UI manager + game loop + mode manager. Logika pertarungan ada di core/sim.js.
import { CHARACTERS, WEAPONS, SKILLS, STAGES, STAT_KEYS, AI_STYLES, PVE_MODES, MODIFIERS, RULES, deriveStats } from './data/data.js';
import { createSim, step, snapshot, surrender, listCombos, buildMoveset, EMPTY_INPUT } from './core/sim.js';
import { createAI, aiInput } from './core/ai.js';
import { World, loadGolem, golem } from './view/render.js';
import { Audio } from './view/audio.js';
import { Net } from './net/net.js';

const $ = (id) => document.getElementById(id);
const store = { get(k, d) { try { const v = localStorage.getItem('pbd.' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem('pbd.' + k, JSON.stringify(v)); } catch (e) {} } };
const CH = Object.keys(CHARACTERS), SG = Object.keys(STAGES);
const S = { // pengaturan + pilihan tersimpan
  set: Object.assign({ master: 0.8, music: 0.5, sfx: 0.9, btn: 1, sens: 1, quality: 'auto', flip: false, shake: true, difficulty: 'normal' }, store.get('settings', {})),
  pick: Object.assign({ char: 'ZUKI', weapon: 'Longsword', stage: 'shadowTemple' }, store.get('pick', {})), prog: store.get('prog', { storyBest: 0, endlessBest: 0 }),
};
if (!CHARACTERS[S.pick.char]) S.pick.char = 'ZUKI';
const save = () => { store.set('settings', S.set); store.set('pick', S.pick); store.set('prog', S.prog); };
for (const k of ['master', 'music', 'sfx']) Audio.vol[k] = S.set[k];

let world, mode = 'menu', G = null, paused = false, net = null, previewT = 0;
const screens = ['load', 'err', 'menu', 'select', 'stageSel', 'pveSel', 'pvpSel', 'joinSel', 'lobby', 'settings', 'about', 'hud', 'overlay'];
// Satu state UI aktif pada satu waktu. Nama state: loading, error, mainMenu, select, stage, pve, multiplayer, joinRoom, lobby, settings, about, fight.
const STATE_OF = { load: 'loading', err: 'error', menu: 'mainMenu', select: 'select', stageSel: 'stage', pveSel: 'pve', pvpSel: 'multiplayer', joinSel: 'joinRoom', lobby: 'lobby', settings: 'settings', about: 'about', hud: 'fight' };
const B = window.pbdBoot || { setStage() {}, fail(m, d) { console.error(m, d); }, done() {}, failed: false };
const fmtErr = (e) => (e && (e.name ? e.name + ': ' : '') + (e.message || e) + (e.stack ? '\n' + e.stack : '')) || String(e);
let engineReady = false;       // true hanya setelah renderer, aset, dan satu frame render berhasil
function show(...ids) {
  if (B.failed) return;                                   // layar error tidak boleh ditimpa
  if (!engineReady && ids[0] !== 'load') return;          // menu/lobby/join TIDAK boleh muncul sebelum engine siap
  for (const sc of screens) $(sc).classList.toggle('on', ids.includes(sc));
  document.body.dataset.ui = STATE_OF[ids[0]] || ids[0]; $('touch').classList.toggle('on', ids.includes('hud') && !G?.noTouch);
}
function click(f) { return (e) => { Audio.ensure(); Audio.sfx('click'); f(e); }; }

/* ------------------------------------------------------------------ boot */
async function boot() {
  B.setStage('Membuat renderer 3D…', 0.3);
  try { world = new World($('world')); const gl = world.renderer.getContext && world.renderer.getContext(); if (!gl) throw new Error('konteks WebGL kosong'); }
  catch (e) { return B.fail('Tidak bisa membuat renderer WebGL2. Browser/perangkat tidak mendukung, atau WebGL dimatikan.', fmtErr(e)); }
  addEventListener('resize', () => { world.resize(); layoutTouch(); }); world.setStage(S.pick.stage);
  B.setStage('Memuat aset Golem…', 0.4);
  const tick = (p) => B.setStage('Memuat aset Golem… ' + Math.round(p * 100) + '%', 0.4 + p * 0.5);
  const r = await Promise.race([loadGolem(tick), new Promise((res) => setTimeout(() => res('timeout'), 15000))]);   // aset berat tidak boleh membuat loading macet
  golemNote = r === true ? '' : r === 'timeout' ? 'Aset Golem terlalu lama dimuat; memakai model prosedural.' : 'Aset Golem gagal dimuat; memakai model prosedural.';
  B.setStage('Menyiapkan menu…', 0.95);
  buildSettings(); buildAbout(); buildTouch(); layoutTouch(); bindMenu(); gotoMenu(); requestAnimationFrame(loop);
  window.addEventListener('keydown', () => Audio.ensure(), { once: true }); window.addEventListener('pointerdown', () => Audio.ensure(), { once: true });
}
let golemNote = '';
const fs = () => { const el = document.documentElement; (el.requestFullscreen || el.webkitRequestFullscreen || (() => {})).call(el); try { screen.orientation && screen.orientation.lock && screen.orientation.lock('landscape').catch(() => {}); } catch (e) {} };
$('fsBtn').onclick = fs;

/* ------------------------------------------------------------------ menu */
function bindMenu() {
  document.querySelectorAll('[data-go]').forEach((b) => (b.onclick = click(() => go(b.dataset.go))));
  $('stageBack').onclick = click(gotoMenu); $('pauseBtn').onclick = click(() => openPause()); $('srvUrl').value = store.get('srv', '');
  $('pvLocal').onclick = click(() => startLocal()); $('pvQuick').onclick = click(() => online('quick', 'pvpSel')); $('pvCreate').onclick = click(() => online('create', 'pvpSel'));
  $('pvJoinGo').onclick = click(() => { netMsg(''); show('joinSel'); }); $('pvJoin').onclick = click(() => online('join', 'joinSel'));
  for (const id of ['pvBack', 'jrBack', 'lbBack']) $(id).onclick = click(gotoMenu);          // semua tombol Kembali multiplayer -> menu utama
  $('roomCode').oninput = () => { $('roomCode').value = $('roomCode').value.toUpperCase().replace(/[^A-Z0-9]/g, ''); };
}
function go(w) {
  if (w === 'menu') return gotoMenu();
  if (w === 'quick') return startPve('story');
  if (w === 'pve') return buildPve();
  if (w === 'pvp') { netMsg('Online butuh server (lihat README). Belum diuji pada dua perangkat nyata.'); show('pvpSel'); return; }
  if (w === 'char' || w === 'weapon') return openSelect(w, null);
  if (w === 'stage') return openStage(gotoMenu);
  if (w === 'training') return startTraining();
  if (w === 'settings') { buildSettings(); return show('settings'); }
  if (w === 'about') return show('about');
}
function gotoMenu() { mode = 'menu'; G = null; paused = false; leaveNet(); $('overlay').classList.remove('on'); show('menu'); world.setStage('shadowTemple'); world.clearFighters(); Audio.music('menu'); const c = CHARACTERS[S.pick.char]; $('menuInfo').textContent = `Terpilih: ${c.name} + ${S.pick.weapon} | Arena: ${STAGES[S.pick.stage].name} | Story terbaik: ${S.prog.storyBest} | Endless terbaik: gelombang ${S.prog.endlessBest}` + (golemNote ? ' | ' + golemNote : ''); }
function buildAbout() { $('aboutBody').innerHTML = '<b>P Bewan Deck</b> — game fighting 3D (HTML/JS/WebGL2, Three.js). Terinspirasi mekanik Shadow Fight; karakter, nama, dan efek dibuat orisinal.<br><br>Aset: Stone Golem (prototipe, FBX) dan senjata GLB yang Anda kirim. Pastikan lisensi tiap aset sesuai sebelum dirilis publik.<br><br>Status jujur: model prosedural dipakai untuk karakter selain Golem; PvP online butuh server yang di-host sendiri dan belum diuji dua perangkat nyata. Lihat docs/LAPORAN.md.'; }

/* ------------------------------------------------------------------ character / weapon select dengan preview nyata */
let sel = { focus: 'char', next: null, anim: 'idle', animT: 0, view: null, key: '' };
function openSelect(focus, next) {
  sel.focus = focus; sel.next = next; mode = 'select'; show('select'); world.setStage('shadowTemple'); world.halfMin = 2.3; previewReset(); renderSelect(); Audio.music('menu');
}
function previewReset() { world.clearFighters(); sel.view = null; sel.key = ''; }
function ensurePreview() {
  const key = S.pick.char + '|' + S.pick.weapon; if (sel.key === key && sel.view) return;
  if (!sel.view || sel.view.char !== S.pick.char) { world.clearFighters(); sel.view = world.addFighter({ idx: 0, char: S.pick.char, weapon: S.pick.weapon, hp: 1 }); }
  else world.setWeapon(sel.view, S.pick.weapon);
  sel.key = key;
}
function previewSnap(dt) {
  sel.animT += dt; const w = WEAPONS[S.pick.weapon], ms = buildMoveset(S.pick.char, S.pick.weapon);
  const f = { idx: 0, char: S.pick.char, weapon: S.pick.weapon, name: '', x: 0, y: 0, face: 1, hp: 1, maxHp: 1, state: 'idle', t: 0, mv: null, mvLen: 0, sk: null, skLen: 0, stamina: 100, meter: 0, cd: {}, shield: 0, charge: 0, crouch: false, buff: false };
  if (sel.anim === 'attack' || sel.anim === 'skill') {
    const seq = sel.anim === 'attack' ? [...w.combo.light, w.combo.heavy] : ['H']; const per = 0.8, i = Math.floor(sel.animT / per) % seq.length, mv = ms.moves[seq[i]], len = mv.s + mv.a + mv.r, p = (sel.animT % per) / per;
    if (sel.anim === 'skill') { f.state = 'skill'; f.skLen = 60; f.t = Math.floor(p * 60); } else if (w.ranged) { f.state = 'charge'; f.mv = 'SHOT_H'; f.charge = p * 60; f.t = 5; f.mvLen = 40; } else { f.state = 'attack'; f.mv = mv.id; f.mvLen = len; f.t = Math.floor(p * len); }
    if (sel.animT > 4.2) sel.anim = 'idle';
  }
  return { f: [f, Object.assign({}, f, { idx: 1, x: 40 })], proj: [], traps: [], ev: [], round: {} };
}
function renderSelect() {
  const c = CHARACTERS[S.pick.char], st = deriveStats(c), w = WEAPONS[S.pick.weapon];
  const bar = (k, label, v, max) => `<div class="stat"><span>${label}</span><div class="bar"><i style="width:${Math.min(100, v / max * 100)}%"></i></div><span>${Math.round(v)}</span></div>`;
  $('selL').innerHTML = `<h3>${c.name}</h3><div class="small"><b>${c.title}</b><br>${c.desc}</div>` +
    bar('hp', 'HP', st.maxHp, 1200) + bar('atk', 'Damage', st.atkMul * 100, 160) + bar('spd', 'Speed', st.speedMul * 50, 80) + bar('def', 'Defense', (1 - st.dmgTaken) * 300, 100) + bar('stun', 'Stun', st.stunMul * 70, 100) + bar('mob', 'Mobility', st.walk * 25, 100) +
    `<div class="small"><b>Skill:</b> ${c.skills.map((s) => SKILLS[s].name).join(', ')}<br><b>Ultimate:</b> ${SKILLS[c.ult].name}<br><b>Pasif:</b> ${c.passive.id} — ${c.passive.desc}</div>` +
    `<div class="row"><button class="chip" id="pvAtk">Lihat Serangan</button><button class="chip" id="pvSkill">Lihat Skill</button></div>`;
  const wl = c.weapons.map((n) => `<button class="chip ${n === S.pick.weapon ? 'sel' : ''}" data-w="${n}">${n}</button>`).join('');
  $('selR').innerHTML = `<h3>${S.pick.weapon}</h3><div class="small">${w.desc}</div><div class="row">${wl}</div>` +
    bar('d', 'Damage', w.dmg * 60, 100) + bar('r', 'Reach', w.reach * 40, 100) + bar('s', 'Speed', w.spd * 60, 100) + bar('rc', 'Recovery', 100 / w.rec * 0.6, 100) + bar('st', 'Stun', w.stun * 60, 100) +
    `<div class="small"><b>Skill senjata:</b> ${SKILLS[w.skill].name}<br>${SKILLS[w.skill].desc}<br><b>Kombo:</b> ${w.combo.light.join(' > ')} | Heavy: ${w.combo.heavy}<br>Model: ${w.model ? 'GLB asli (' + w.model + ')' : 'prosedural (belum ada aset)'}</div>`;
  $('selNav').innerHTML = `<button class="btn" id="prev">◀</button><button class="btn" id="next">▶</button><button class="btn pri" id="ok">Konfirmasi</button><button class="btn" id="bk">Kembali</button>`;
  $('selR').querySelectorAll('[data-w]').forEach((b) => (b.onclick = click(() => { S.pick.weapon = b.dataset.w; save(); sel.anim = 'attack'; sel.animT = 0; renderSelect(); })));
  $('pvAtk').onclick = click(() => { sel.anim = 'attack'; sel.animT = 0; }); $('pvSkill').onclick = click(() => { sel.anim = 'skill'; sel.animT = 0; });
  const cyc = (d) => { const i = (CH.indexOf(S.pick.char) + d + CH.length) % CH.length; S.pick.char = CH[i]; if (!CHARACTERS[S.pick.char].weapons.includes(S.pick.weapon)) S.pick.weapon = CHARACTERS[S.pick.char].defaultWeapon; save(); sel.anim = 'idle'; renderSelect(); };
  $('prev').onclick = click(() => cyc(-1)); $('next').onclick = click(() => cyc(1)); $('bk').onclick = click(() => { Audio.sfx('back'); world.halfMin = 5.2; if (sel.next) sel.next(false); else gotoMenu(); });
  $('ok').onclick = click(() => { Audio.sfx('confirm'); world.halfMin = 5.2; save(); if (sel.next) sel.next(true); else gotoMenu(); });
}
function openStage(back, next) {
  show('stageSel'); $('stageGrid').innerHTML = SG.map((k) => { const s = STAGES[k], hex = (n) => '#' + n.toString(16).padStart(6, '0'); return `<button class="btn ${k === S.pick.stage ? 'sel' : ''}" data-s="${k}" style="min-height:92px;background:linear-gradient(${hex(s.sky[0])},${hex(s.sky[2])});text-align:left"><b>${s.name}</b><br><span class="small">${s.desc}</span></button>`; }).join('') + `<button class="btn" data-s="random" style="min-height:92px">Random Stage</button>`;
  $('stageGrid').querySelectorAll('[data-s]').forEach((b) => (b.onclick = click(() => { S.pick.stage = b.dataset.s === 'random' ? SG[Math.floor(Math.random() * SG.length)] : b.dataset.s; save(); world.setStage(S.pick.stage); if (next) next(); else openStage(back, next); })));
  $('stageBack').onclick = click(back);
}

/* ------------------------------------------------------------------ settings */
function buildSettings() {
  const r = (k, label, min, max, st, fmt = (v) => Math.round(v * 100)) => `<div class="range"><span>${label}</span><input type="range" data-k="${k}" min="${min}" max="${max}" step="${st}" value="${S.set[k]}"><span>${fmt(S.set[k])}</span></div>`;
  $('setBody').innerHTML = r('master', 'Master volume', 0, 1, 0.05) + r('music', 'Musik', 0, 1, 0.05) + r('sfx', 'Efek suara', 0, 1, 0.05) + r('btn', 'Ukuran tombol', 0.7, 1.4, 0.05, (v) => v.toFixed(2)) + r('sens', 'Sensitivitas joystick', 0.6, 1.6, 0.05, (v) => v.toFixed(2)) +
    `<div class="row"><span>Kualitas:</span>${['auto', 'high', 'low'].map((q) => `<button class="chip ${S.set.quality === q ? 'sel' : ''}" data-q="${q}">${q}</button>`).join('')}</div>` +
    `<div class="row"><span>Kesulitan AI:</span>${['easy', 'normal', 'hard'].map((q) => `<button class="chip ${S.set.difficulty === q ? 'sel' : ''}" data-d="${q}">${q}</button>`).join('')}</div>` +
    `<div class="row"><button class="chip ${S.set.shake ? 'sel' : ''}" id="tShake">Camera shake: ${S.set.shake ? 'ON' : 'OFF'}</button><button class="chip ${S.set.flip ? 'sel' : ''}" id="tFlip">Balik arah model Golem: ${S.set.flip ? 'ON' : 'OFF'}</button><button class="chip" id="tFs">Layar penuh + landscape</button></div>`;
  $('setBody').querySelectorAll('input[type=range]').forEach((i) => (i.oninput = () => { const k = i.dataset.k; S.set[k] = Number(i.value); i.nextElementSibling.textContent = k === 'btn' || k === 'sens' ? S.set[k].toFixed(2) : Math.round(S.set[k] * 100); if (['master', 'music', 'sfx'].includes(k)) Audio.set(k, S.set[k]); if (k === 'btn') layoutTouch(); save(); }));
  $('setBody').querySelectorAll('[data-q]').forEach((b) => (b.onclick = click(() => { S.set.quality = b.dataset.q; applyQuality(true); save(); buildSettings(); })));
  $('setBody').querySelectorAll('[data-d]').forEach((b) => (b.onclick = click(() => { S.set.difficulty = b.dataset.d; save(); buildSettings(); })));
  $('tShake').onclick = click(() => { S.set.shake = !S.set.shake; save(); buildSettings(); }); $('tFlip').onclick = click(() => { S.set.flip = !S.set.flip; save(); buildSettings(); }); $('tFs').onclick = click(fs);
}

/* ------------------------------------------------------------------ input: joystick + tombol multi-touch + keyboard */
const inp = [Object.assign({}, EMPTY_INPUT), Object.assign({}, EMPTY_INPUT)]; const touch = { x: 0, up: false, down: false, keys: {} }, keys = new Set();
const BTNS = [['light', 'Light', 0, 0, 86], ['heavy', 'Heavy', 96, 18, 76], ['guard', 'Guard', 8, 96, 66], ['dodge', 'Dodge', 80, 102, 60], ['dash', 'Dash', 148, 92, 54], ['s1', 'S1', 214, 12, 60], ['s2', 'S2', 220, 78, 56], ['ws', 'WS', 152, 150, 54], ['ult', 'ULT', 8, 168, 56]];
function buildTouch() {
  const R = $('right'); R.innerHTML = ''; for (const [k, label] of BTNS) { const b = document.createElement('button'); b.className = 'tb'; b.dataset.k = k; b.innerHTML = `<span>${label}</span><i class="cd" style="height:0"></i>`; R.appendChild(b);
    const on = (e) => { e.preventDefault(); touch.keys[k] = true; b.classList.add('down'); try { b.setPointerCapture(e.pointerId); } catch (_) {} }, off = () => { touch.keys[k] = false; b.classList.remove('down'); };
    b.addEventListener('pointerdown', on); b.addEventListener('pointerup', off); b.addEventListener('pointercancel', off); b.addEventListener('lostpointercapture', off); }
  const st = $('stick'), kn = $('knob'); let pid = null;
  const mv = (e) => { const r = st.getBoundingClientRect(), R2 = r.width / 2, dx = (e.clientX - r.left - R2) / (R2 / S.set.sens), dy = (e.clientY - r.top - R2) / (R2 / S.set.sens); touch.x = Math.abs(dx) < 0.22 ? 0 : Math.max(-1, Math.min(1, dx)); touch.up = dy < -0.55; touch.down = dy > 0.55; kn.style.transform = `translate(${Math.max(-1, Math.min(1, dx)) * R2 * 0.5}px,${Math.max(-1, Math.min(1, dy)) * R2 * 0.5}px)`; };
  st.addEventListener('pointerdown', (e) => { e.preventDefault(); pid = e.pointerId; st.setPointerCapture(pid); mv(e); }); st.addEventListener('pointermove', (e) => { if (e.pointerId === pid) mv(e); });
  const end = (e) => { if (e.pointerId !== pid) return; pid = null; touch.x = 0; touch.up = touch.down = false; kn.style.transform = ''; }; st.addEventListener('pointerup', end); st.addEventListener('pointercancel', end);
}
function layoutTouch() { const b = S.set.btn; document.documentElement.style.setProperty('--btn', b); document.querySelectorAll('#right .tb').forEach((el) => { const d = BTNS.find((x) => x[0] === el.dataset.k); el.style.right = d[2] * b + 'px'; el.style.bottom = d[3] * b + 'px'; el.style.width = el.style.height = d[4] * b + 'px'; }); }
const K1 = { KeyA: 'left', KeyD: 'right', KeyW: 'up', KeyS: 'down', KeyJ: 'light', KeyK: 'heavy', KeyL: 'guard', KeyU: 'dodge', KeyI: 'dash', Digit1: 's1', Digit2: 's2', Digit3: 'ws', Digit4: 'ult' };
const K2 = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down', Comma: 'light', Period: 'heavy', Slash: 'guard', Semicolon: 'dodge', Quote: 'dash', BracketLeft: 's1', BracketRight: 's2', Backslash: 'ws', Enter: 'ult' };
addEventListener('keydown', (e) => { if (K1[e.code] || K2[e.code]) e.preventDefault(); keys.add(e.code); if (e.code === 'Escape' && mode === 'fight') openPause(); });
addEventListener('keyup', (e) => keys.delete(e.code));
function readInput(map, touchToo) {
  const o = Object.assign({}, EMPTY_INPUT); let l = 0, r = 0; for (const [code, k] of Object.entries(map)) if (keys.has(code)) { if (k === 'left') l = 1; else if (k === 'right') r = 1; else o[k] = true; }
  o.x = r - l; if (touchToo) { if (touch.x) o.x = touch.x; o.up = o.up || touch.up; o.down = o.down || touch.down; for (const k in touch.keys) if (touch.keys[k]) o[k] = true; } return o;
}
// input relatif layar -> relatif hadap: sim memakai x dunia, sehingga tidak perlu konversi.

/* ------------------------------------------------------------------ memulai pertandingan */
function applyQuality(force) { if (S.set.quality === 'high') world.setScale(Math.min(devicePixelRatio || 1, 2)); else if (S.set.quality === 'low') world.setScale(0.6); else if (force) world.setScale(Math.min(devicePixelRatio || 1, 1.5)); world.quality = S.set.quality === 'low' ? 0.3 : 1; world.resize(); }
function beginMatch(cfg, kind, extra = {}) {
  G = Object.assign({ cfg, kind, ai: null, acc: 0, over: false, noTouch: false, last: performance.now(), frames: 0, ftAvg: 16, banner: 0 }, extra); mode = 'fight'; paused = false;
  G.sim = createSim(cfg); world.halfMin = 5.2; world.setStage(cfg.stage); applyQuality(); world.clearFighters(); const s0 = snapshot(G.sim); for (const f of s0.f) world.addFighter(f);
  show('hud'); $('overlay').classList.remove('on'); Audio.music(STAGES[cfg.stage].music); buildHudStatic(s0); G.shown = {};
  $('trainInfo').textContent = kind === 'training' ? 'TRAINING: tidak ada timer. Buka Pause untuk daftar combo.' : '';
}
function aiFor(extra = {}) { return createAI(extra.style || 'aggressive', extra.diff || S.set.difficulty, (Math.random() * 1e6) | 0); }
function myCfg(extra) { return Object.assign({ p1: { char: S.pick.char, weapon: S.pick.weapon }, stage: S.pick.stage, seed: (Math.random() * 1e9) | 0 }, extra); }
function startLocal() { beginMatch(myCfg({ p2: { char: CH[(CH.indexOf(S.pick.char) + 1) % CH.length], weapon: null } }), 'local'); }
function startTraining() {
  openSelect('char', (okk) => { if (!okk) return gotoMenu(); const opp = CH.find((c) => c !== S.pick.char); const cfg = myCfg({ p2: { char: opp, weapon: CHARACTERS[opp].defaultWeapon }, training: true, noUlt: false }); beginMatch(cfg, 'training', { ai: null, dummy: 'idle' }); });
}

/* ------------------------------------------------------------------ PvE */
function buildPve() {
  show('pveSel'); $('pveGrid').innerHTML = Object.entries(PVE_MODES).map(([k, m]) => `<button class="btn" data-m="${k}" style="min-height:90px;text-align:left"><b>${m.name}</b><br><span class="small">${m.desc}</span></button>`).join('');
  $('pveGrid').querySelectorAll('[data-m]').forEach((b) => (b.onclick = click(() => startPve(b.dataset.m))));
}
function startPve(m) {
  openSelect('char', (okk) => { if (!okk) return gotoMenu(); openStage(gotoMenu, () => { G = null; pve = { m, i: 0, wave: 0, hpRatio: 1 }; nextPveFight(); }); });
}
let pve = null;
function pveOpponent() {
  const M = PVE_MODES[pve.m], styles = Object.keys(AI_STYLES).filter((s) => s !== 'boss'); let char, style, diff = S.set.difficulty, hpMul = 1, mods = null, noUlt = false, label = '';
  if (pve.m === 'story') { const e = M.list[pve.i % M.list.length]; char = e[0] === S.pick.char ? CH.find((c) => c !== S.pick.char) : e[0]; style = e[1]; label = `Story ${pve.i + 1}/${M.list.length}`; }
  else if (pve.m === 'survival') { char = CH[(pve.wave * 2 + 1) % CH.length]; style = styles[pve.wave % styles.length]; diff = pve.wave > 3 ? 'hard' : diff; label = `Survival: lawan ${pve.wave + 1}`; }
  else if (pve.m === 'endless') { char = CH[Math.floor(Math.random() * CH.length)]; style = styles[Math.floor(Math.random() * styles.length)]; diff = pve.wave > 4 ? 'hard' : pve.wave > 1 ? 'normal' : 'easy'; hpMul = 1 + Math.min(0.3, pve.wave * 0.03); label = `Gelombang ${pve.wave + 1}`; }
  else if (pve.m === 'elite') { char = CH[Math.floor(Math.random() * CH.length)]; style = ['counter', 'evasive', 'aggressive'][Math.floor(Math.random() * 3)]; diff = 'hard'; noUlt = true; label = 'Elite Challenge'; }
  else if (pve.m === 'boss') { char = 'TITAN'; style = 'boss'; hpMul = 1.35; label = 'BOSS: TITAN'; }
  else { const keys = Object.keys(MODIFIERS), mk = keys[Math.floor(Date.now() / 864e5) % keys.length]; mods = MODIFIERS[mk]; char = CH[Math.floor(Date.now() / 864e5) % CH.length]; style = styles[Math.floor(Date.now() / 864e5) % styles.length]; label = `Daily: ${mods.name} (${mods.desc})`; noUlt = !!mods.noUlt; }
  if (char === S.pick.char && pve.m !== 'boss') char = CH.find((c) => c !== S.pick.char);
  return { char, style, diff, hpMul, mods, noUlt, label };
}
function nextPveFight() {
  const o = pveOpponent(); const w = CHARACTERS[o.char].defaultWeapon; const cfg = myCfg({ p2: { char: o.char, weapon: w, hpMul: o.hpMul }, mods: o.mods, noUlt: o.noUlt, startHpRatio: pve.m === 'survival' ? pve.hpRatio : 0 });
  beginMatch(cfg, 'pve', { ai: aiFor({ style: o.style, diff: o.diff }), pveLabel: o.label, opp: o });
  banner(o.label, 1200);
}
function onPveEnd(res) {
  const won = res.winner === 0, M = PVE_MODES[pve.m], pf = G.sim.f[0]; let msg = '', next = null;
  if (won) {
    pve.i++; pve.wave++; const last = pf.hp / pf.maxHp; pve.hpRatio = Math.min(1, last + (1 - last) * (M.carryHp || 1));
    if (pve.m === 'story') { S.prog.storyBest = Math.max(S.prog.storyBest, pve.i); if (pve.i >= M.list.length) msg = 'Story selesai!'; else next = 'Lawan berikutnya'; }
    else if (['survival', 'endless'].includes(pve.m)) { if (pve.m === 'endless') S.prog.endlessBest = Math.max(S.prog.endlessBest, pve.wave); next = 'Lawan berikutnya'; }
    else msg = 'Tantangan selesai!';
  } else msg = pve.m === 'endless' ? `Bertahan sampai gelombang ${pve.wave}.` : 'Kalah.';
  save(); resultOverlay(won, res, msg, next);
}

/* ------------------------------------------------------------------ online */
let netBusy = false, netTimer = 0, netFrom = 'pvpSel';
const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function netSet(on) { for (const id of ['pvLocal', 'pvQuick', 'pvCreate', 'pvJoinGo', 'pvJoin']) { const e = $(id); if (e) e.disabled = !on; } }
function netMsg(t, bad, spin) { for (const id of ['pvStatus', 'jrStatus', 'lbStatus']) { const e = $(id); if (!e) continue; e.classList.toggle('bad', !!bad); e.innerHTML = (spin ? '<span class="spin"></span>' : '') + esc(t); } }
function leaveNet() { clearTimeout(netTimer); if (net) { const n = net; net = null; n.close(); } netBusy = false; netSet(true); }
function netFail(msg) { const wasLobby = document.body.dataset.ui === 'lobby'; leaveNet(); netMsg(msg, true); if (wasLobby || document.body.dataset.ui === 'fight') { mode = 'menu'; G = null; show(netFrom); } }
async function online(kind, from) {
  if (netBusy) return; netFrom = from; const url = $('srvUrl').value.trim();
  let code = ''; if (kind === 'join') { code = $('roomCode').value.trim().toUpperCase(); if (!/^[A-Z0-9]{4}$/.test(code)) { netMsg('Room ID harus 4 huruf/angka.', true); return; } }
  if (!/^wss?:\/\/.+/i.test(url)) { netMsg('Isi alamat server dulu di layar Multiplayer (contoh ws://192.168.1.5:8080).', true); show('pvpSel'); return; }
  if (location.protocol === 'https:' && /^ws:/i.test(url)) { netMsg('Halaman ini HTTPS (mis. itch.io) sehingga browser memblokir ws://. Gunakan server dengan TLS (wss://).', true); show('pvpSel'); return; }
  store.set('srv', url); leaveNet(); netBusy = true; netSet(false); netMsg('Menghubungkan ke ' + url + '…', false, true);
  const my = new Net(); net = my; let joined = false;
  try { await my.connect(url); } catch (e) { if (net === my) netFail('Koneksi gagal: server tidak merespons (' + e.message + '). Periksa alamat dan pastikan server berjalan.'); return; }
  if (net !== my) return;
  netMsg('Terhubung. Menunggu respons server…', false, true);
  netTimer = setTimeout(() => { if (net === my && !joined) netFail('Server terhubung tetapi tidak membalas dalam 6 detik.'); }, 6000);   // jangan menganggap sukses sebelum server membalas
  my.on.joined = (m) => { if (net !== my) return; joined = true; clearTimeout(netTimer); netBusy = false; netSet(true); my.idx = m.idx; $('lbCode').textContent = m.code || '----'; netMsg(m.idx === 0 ? 'Menunggu lawan…' : 'Lawan ditemukan, memulai…', false, m.idx === 0); show('lobby'); };
  my.on.error = (m) => { if (net === my) netFail(m.msg || 'Server menolak permintaan.'); };
  my.on.start = (m) => { if (net === my) onlineStart(m.cfg); };
  my.on.state = (m) => { if (G && G.kind === 'online' && net === my) { G.latest = m.s; G.evq.push(...m.s.ev); } };
  my.on.opponentDisconnected = () => banner('Lawan terputus… menunggu 15 dtk', 3000); my.on.opponentReconnected = () => banner('Lawan tersambung kembali', 1500);
  my.on.close = () => { if (net !== my) return; if (G && G.kind === 'online' && !G.over) { banner('Koneksi terputus', 3000); $('net').textContent = 'OFFLINE'; } else netFail(joined ? 'Koneksi ke server terputus.' : 'Koneksi ditutup server sebelum merespons.'); };
  const pick = { char: S.pick.char, weapon: S.pick.weapon };
  if (kind === 'quick') my.send({ t: 'quick', pick, stage: S.pick.stage }); else if (kind === 'create') my.send({ t: 'create', pick, stage: S.pick.stage }); else my.send({ t: 'join', code, pick });
}
function onlineStart(cfg) {
  G = { cfg, kind: 'online', noTouch: false, over: false, evq: [], latest: null, acc: 0, last: performance.now(), ftAvg: 16, idx: net.idx, shown: {} }; mode = 'fight'; paused = false;
  world.halfMin = 5.2; world.setStage(cfg.stage); applyQuality(); world.clearFighters(); const mk = (p, i) => ({ idx: i, char: p.char, weapon: p.weapon, hp: 1 }); world.addFighter(mk(cfg.p1, 0)); world.addFighter(mk(cfg.p2, 1));
  show('hud'); $('overlay').classList.remove('on'); Audio.music(STAGES[cfg.stage].music); G.fresh = true;
}

/* ------------------------------------------------------------------ HUD, banner, pause, hasil */
let bannerT = 0; function banner(t, ms = 1000) { const b = $('banner'); b.textContent = t; b.classList.add('on'); clearTimeout(bannerT); bannerT = setTimeout(() => b.classList.remove('on'), ms); }
function buildHudStatic(s) { $('n0').textContent = s.f[0].name; $('n1').textContent = s.f[1].name; }
function updateHud(s) {
  const [a, b] = s.f; for (let i = 0; i < 2; i++) { const f = s.f[i], r = Math.max(0, f.hp / f.maxHp); $('f' + i).style.transform = `scaleX(${r})`; $('l' + i).style.transform = `scaleX(${r})`; $('h' + i).textContent = Math.ceil(f.hp); $('s' + i).style.width = f.stamina + '%'; $('m' + i).style.width = f.meter + '%'; $('n' + i).textContent = f.name; }
  $('timer').textContent = s.round.sudden ? 'SD' : G.kind === 'training' ? '∞' : Math.max(0, Math.ceil(s.round.timer / 60)); $('rnd').textContent = (s.round.sudden ? 'Sudden Death ' : '') + `Round ${Math.min(3, s.round.no || 1)}/3`;
  $('pips').innerHTML = [0, 1].map((i) => `<span class="pip ${s.round.wins[i] > 0 ? 'w' : ''}"></span><span class="pip ${s.round.wins[i] > 1 ? 'w' : ''}"></span>`).join('<span style="width:12px"></span>');
  const me = s.f[G.idx || 0], ch = CHARACTERS[me.char]; const ids = { s1: ch.skills[0], s2: ch.skills[1], ws: WEAPONS[me.weapon].skill };
  document.querySelectorAll('#right .tb').forEach((el) => { const k = el.dataset.k; let ratio = 0, rdy = false; if (ids[k]) { const mx = SKILLS[ids[k]].cd || 1; ratio = me.cd[k] / mx; rdy = me.cd[k] <= 0; } else if (k === 'ult') { ratio = 1 - me.meter / 100; rdy = me.meter >= 100; } else if (k === 'dodge' || k === 'dash') ratio = me.stamina < 25 ? 0.7 : 0; el.querySelector('.cd').style.height = Math.min(100, ratio * 100) + '%'; el.classList.toggle('rdy', rdy); });
  if (G.net) $('net').textContent = 'Ping ' + (G.net.ping || '-') + ' ms';
}
function handleEvents(evs, s) {
  for (const e of evs) {
    world.fx(e, s);
    switch (e.t) {
      case 'swing': if (e.move !== 'skillhit' || true) Audio.sfx('swing', e.weapon); break; case 'hit': Audio.sfx('hit', e); if (e.combo >= 3 && s.f[e.f ^ 1]) banner(e.combo + ' HIT', 500); break;
      case 'block': Audio.sfx('block'); break; case 'parry': Audio.sfx('parry'); banner('PARRY!', 500); break; case 'perfectDodge': Audio.sfx('perfectDodge'); banner('PERFECT DODGE', 500); break;
      case 'dodge': Audio.sfx('dodge'); break; case 'dash': Audio.sfx('dash'); break; case 'jump': Audio.sfx('jump'); break; case 'land': Audio.sfx('land'); break; case 'shoot': Audio.sfx('shoot'); break;
      case 'knockdown': Audio.sfx('knockdown'); break; case 'getup': Audio.sfx('getup'); break; case 'guardBreak': Audio.sfx('guardBreak'); banner('GUARD BREAK', 600); break; case 'stun': Audio.sfx('stun'); break;
      case 'telegraph': Audio.sfx(e.ult ? 'ult' : 'skill'); if (G.kind !== 'training' && e.f !== (G.idx || 0) && (e.ult || (G.opp && G.opp.style === 'boss'))) { const d = $('danger'); d.classList.add('on'); setTimeout(() => d.classList.remove('on'), Math.max(300, e.frames * 16)); } break;
      case 'area': case 'teleport': case 'counterStance': case 'trap': Audio.sfx('skill'); break;
      case 'roundStart': banner(`ROUND ${e.no}`, 1100); Audio.sfx('roundStart'); break; case 'fight': banner('FIGHT!', 700); Audio.sfx('fight'); break;
      case 'sudden': banner('SUDDEN DEATH', 1400); break; case 'roundEnd': Audio.sfx('roundEnd'); banner(e.winner === (G.idx || 0) ? 'ROUND MENANG' : 'ROUND KALAH', 1300); break;
      case 'ko': banner('K.O.', 1200); break; case 'bossPhase': banner('FASE ' + e.phase, 1400); break;
    }
  }
}
function openPause() {
  if (mode !== 'fight' || !G) return; const onl = G.kind === 'online'; if (!onl) paused = true; const ov = $('overlay'); ov.classList.add('on');
  ov.innerHTML = `<h1>PAUSE</h1>${onl ? '<div class="small">Online: game tetap berjalan.</div>' : ''}<div class="col" style="min-width:260px"><button class="btn pri" id="pResume">Lanjut</button><button class="btn" id="pCombo">Daftar Combo</button><button class="btn" id="pSet">Pengaturan Suara</button><button class="btn danger" id="pGive">Give Up / Menyerah</button><button class="btn" id="pMenu">Menu Utama</button></div>`;
  $('pResume').onclick = click(() => { paused = false; ov.classList.remove('on'); }); $('pCombo').onclick = click(showCombos); $('pSet').onclick = click(() => { buildSettings(); ov.innerHTML = '<h1>SUARA</h1><div class="panel col" style="min-width:min(90vw,520px)">' + $('setBody').innerHTML + '</div><button class="btn" id="pBack">Kembali</button>'; wireSettingsOverlay(); });
  $('pGive').onclick = click(() => { ov.innerHTML = '<h1>Menyerah?</h1><div class="small">Pertandingan dihitung sebagai kekalahan.</div><div class="row"><button class="btn danger" id="gYes">Ya, menyerah</button><button class="btn" id="gNo">Batal</button></div>'; $('gNo').onclick = click(openPause); $('gYes').onclick = click(doSurrender); });
  $('pMenu').onclick = click(() => { ov.classList.remove('on'); gotoMenu(); });
}
function wireSettingsOverlay() { const ov = $('overlay'); ov.querySelectorAll('input[type=range]').forEach((i) => (i.oninput = () => { S.set[i.dataset.k] = Number(i.value); if (['master', 'music', 'sfx'].includes(i.dataset.k)) Audio.set(i.dataset.k, S.set[i.dataset.k]); save(); })); $('pBack').onclick = click(openPause); }
function showCombos() {
  const me = G.sim ? G.sim.f[0] : null, ck = me ? me.charKey : S.pick.char, wk = me ? me.weaponName : S.pick.weapon; const ov = $('overlay');
  ov.innerHTML = `<h1>COMBO: ${ck} + ${wk}</h1><div class="panel list">${listCombos(ck, wk).map((l) => '• ' + l).join('<br>')}<br><br><b>Kontrol keyboard P1:</b> A/D gerak, W lompat, S nunduk, J Light, K Heavy, L Guard, U Dodge, I Dash, 1/2 skill, 3 weapon skill, 4 ultimate.</div><button class="btn" id="cBack">Kembali</button>`; $('cBack').onclick = click(openPause);
}
function doSurrender() {
  $('overlay').classList.remove('on'); paused = false; if (G.kind === 'online') { net && net.send({ t: 'surrender' }); return; }
  surrender(G.sim, 0); finishMatch();
}
function resultOverlay(won, res, msg, next) {
  const ov = $('overlay'); ov.classList.add('on'); const st = G.sim ? G.sim.f[0].stats : {}; const me = G.idx || 0;
  ov.innerHTML = `<h1 style="color:${won ? '#8fd3ff' : '#ff6a3d'}">${won ? 'MENANG' : 'KALAH'}</h1><div class="small">${res.reason === 'surrender' ? 'Menyerah / terputus' : 'Skor ronde ' + res.wins[0] + ' - ' + res.wins[1]} ${msg}</div><div class="small">Damage ${Math.round(st.dealt || 0)} | Hit ${st.hits || 0} | Block ${st.blocks || 0} | Parry ${st.parries || 0} | Perfect Dodge ${st.dodges || 0}</div>` +
    `<div class="row" style="justify-content:center">${next ? `<button class="btn pri" id="rNext">${next}</button>` : ''}<button class="btn ${next ? '' : 'pri'}" id="rRe">Rematch</button><button class="btn" id="rChar">Character Select</button><button class="btn" id="rMenu">Main Menu</button></div>`;
  if (next) $('rNext').onclick = click(() => { ov.classList.remove('on'); nextPveFight(); });
  $('rRe').onclick = click(() => { ov.classList.remove('on'); if (G.kind === 'online') { net.send({ t: 'rematch' }); banner('Menunggu lawan…', 2000); } else if (G.kind === 'pve') { if (pve.m === 'endless' || pve.m === 'survival') { if (!won) { pve.wave = 0; pve.i = 0; pve.hpRatio = 1; } } nextPveFight(); } else beginMatch(G.cfg, G.kind, { ai: G.ai, dummy: G.dummy }); });
  $('rChar').onclick = click(() => { ov.classList.remove('on'); const k = G.kind; openSelect('char', (okk) => { if (!okk) return gotoMenu(); if (k === 'pve') { pve.i = 0; pve.wave = 0; pve.hpRatio = 1; nextPveFight(); } else if (k === 'online') gotoMenu(); else beginMatch(Object.assign({}, G.cfg, { p1: { char: S.pick.char, weapon: S.pick.weapon } }), k, { ai: G.ai }); }); });
  $('rMenu').onclick = click(() => { ov.classList.remove('on'); gotoMenu(); });
}
function finishMatch() {
  if (G.over) return; G.over = true; const res = G.sim.result, won = res.winner === 0; Audio.sfx(won ? 'victory' : 'defeat');
  setTimeout(() => { if (mode !== 'fight' || !G) return; if (G.kind === 'pve') onPveEnd(res); else resultOverlay(won, res, '', null); }, 1500);
}

/* ------------------------------------------------------------------ loop utama: fixed timestep 60 Hz + render */
let lastT = performance.now(), perfAcc = 0, perfN = 0;
let loopErr = false;
function loop(now) {
  requestAnimationFrame(loop);
  try { frame(now); if (!engineReady) { engineReady = true; show('menu'); B.setStage('Siap.', 1); B.done(); } }   // menu baru muncul setelah frame render pertama sukses
  catch (e) { if (!engineReady) B.fail('Error saat render frame pertama (engine 3D belum siap).', fmtErr(e)); else if (!loopErr) { loopErr = true; console.error('Error loop:', e); } }
}
function frame(now) {
  const dt = Math.min(0.1, (now - lastT) / 1000); lastT = now;
  perfAcc += dt; perfN++; if (perfAcc > 2) { adapt(perfAcc / perfN); perfAcc = perfN = 0; }
  if (mode === 'select') { ensurePreview(); world.render(previewSnap(dt), dt, S.set.flip, false); return; }
  if (mode === 'fight' && G) { fightFrame(dt); return; }
  world.render({ f: [{ x: -2, y: 0, face: 1, hp: 1, maxHp: 1 }, { x: 2, y: 0, face: -1, hp: 1, maxHp: 1 }], proj: [], traps: [], ev: [] }, dt, S.set.flip, false);
}
function fightFrame(dt) {
  let snap;
  if (G.kind === 'online') {
    if (net) { const i = readInput(K1, true); net.sendInput(i); G.net = net; }
    snap = G.latest || null; if (snap) { handleEvents(G.evq, snap); G.evq = []; if (snap.round.state === 'matchEnd' && !G.over && snap.result) { G.over = true; G.sim = { f: [{ stats: {} }] }; const won = snap.result.winner === G.idx; Audio.sfx(won ? 'victory' : 'defeat'); setTimeout(() => resultOverlay(won, snap.result.winner === G.idx ? Object.assign({}, snap.result, { winner: 0 }) : Object.assign({}, snap.result, { winner: 1 }), '', null), 1500); } updateHud(snap); world.render(snap, dt, S.set.flip, S.set.shake); }
    return;
  }
  if (!paused) {
    G.acc += dt; let n = 0;
    while (G.acc >= 1 / 60 && n++ < 4) {
      G.acc -= 1 / 60; const sim = G.sim; inp[0] = readInput(K1, true);
      if (G.kind === 'local') inp[1] = readInput(K2, false); else if (G.kind === 'training') inp[1] = G.dummy === 'ai' ? (G.ai ||= aiFor({ style: 'aggressive' }), aiInput(sim, 1, G.ai)) : G.dummy === 'guard' ? Object.assign({}, EMPTY_INPUT, { guard: true }) : EMPTY_INPUT; else inp[1] = aiInput(sim, 1, G.ai);
      step(sim, inp); if (sim.events.length) handleEvents(sim.events, snapshot(sim));
      if (sim.round.state === 'matchEnd' && !G.over) finishMatch();
    }
  }
  snap = snapshot(G.sim); updateHud(snap); world.render(snap, paused ? 0 : dt, S.set.flip, S.set.shake);
}
// manajer performa: turunkan resolusi render jika lambat; naikkan lagi jika lega
function adapt(avg) {
  if (S.set.quality !== 'auto') return; const fps = 1 / avg; if (fps < 40 && world.scale > 0.55) { world.setScale(Math.max(0.55, world.scale - 0.15)); world.quality = 0.4; world.resize(); }
  else if (fps > 56 && world.scale < Math.min(devicePixelRatio || 1, 1.5)) { world.setScale(Math.min(Math.min(devicePixelRatio || 1, 1.5), world.scale + 0.1)); world.quality = 1; world.resize(); }
}
// dummy training selector
document.addEventListener('keydown', (e) => { if (G && G.kind === 'training' && e.code === 'KeyT') { G.dummy = G.dummy === 'idle' ? 'guard' : G.dummy === 'guard' ? 'ai' : 'idle'; banner('Dummy: ' + G.dummy, 800); } });
boot().catch((e) => { console.error(e); B.fail('Error saat inisialisasi game.', fmtErr(e)); });
