// AI: hanya membaca state yang bisa diamati (posisi, state, frame serangan lawan) dengan jeda reaksi.
// Tidak pernah membaca input lawan sebelum aksinya dimulai.
import { AI_STYLES, DIFFICULTY, CHARACTERS } from '../data/data.js';
import { EMPTY_INPUT, makeRng } from './sim.js';

export function createAI(style = 'aggressive', difficulty = 'normal', seed = 7) {
  const S = AI_STYLES[style], D = DIFFICULTY[difficulty];
  return { style, S, D, rng: makeRng(seed), queue: [], think: 0, hold: null, pulse: null, plan: [], wait: 0, phase: 1, lastPhase: 1 };
}
const observe = (o) => ({ state: o.state, t: o.t, x: o.x, y: o.y, mv: o.move ? { s: o.move.s, a: o.move.a, reach: o.move.reach } : o.skill ? { s: o.skill.s || 10, a: 6, reach: o.skill.kind === 'projectile' ? 9 : 2.2, sk: true } : null });

export function aiInput(sim, idx, ai) {
  const me = sim.f[idx], opp = sim.f[1 - idx], S = ai.S, D = ai.D, rng = ai.rng;
  const inp = Object.assign({}, EMPTY_INPUT);
  if (sim.round.state !== 'fight') return inp;
  ai.queue.push(observe(opp)); const delay = S.react + D.reactAdd; while (ai.queue.length > delay + 1) ai.queue.shift();
  const seen = ai.queue[0];                                   // apa yang AI lihat 'delay' frame lalu
  const dist = Math.abs(opp.x - me.x), dir = Math.sign(opp.x - me.x) || me.face, reach = me.w.reach + 0.55;   // +offset badan (hitbox mulai dari tepi badan)
  const hpr = me.hp / me.maxHp;
  // fase boss
  if (S.phases) { ai.phase = hpr > 0.66 ? 1 : hpr > 0.33 ? 2 : 3; if (ai.phase !== ai.lastPhase) { ai.lastPhase = ai.phase; ai.wait = 40; sim.events.push({ t: 'bossPhase', phase: ai.phase }); } }
  const phaseMul = S.phases ? 1 + (ai.phase - 1) * 0.35 : 1;
  // sisa aksi berdenyut/ditahan
  if (ai.pulse) { inp[ai.pulse.k] = true; if (ai.pulse.x !== undefined) inp.x = ai.pulse.x; if (--ai.pulse.n <= 0) ai.pulse = null; return inp; }
  if (ai.hold) { Object.assign(inp, ai.hold.i); if (--ai.hold.n <= 0) ai.hold = null; return inp; }
  // sambung kombo: setelah serangan terkonfirmasi, tekan lagi di jendela cancel (AI juga memakai buffer yang sama dengan pemain)
  if (me.state === 'attack' && me.move && !me.move.shot && me.connected && me.t >= me.move.s + me.move.a - 1 && me.t < me.move.s + me.move.a + 10 && rng() < 0.55 + 0.3 * S.atkRate) {
    if (S.preferHeavy && me.comboDealt >= 2 && rng() < S.preferHeavy) inp.heavy = true; else if (me.comboDealt >= 3 && rng() < 0.3 && me.cd.ws <= 0) inp.ws = true; else inp.light = true;
    return inp;
  }
  const busy = !['idle', 'walk', 'crouch', 'guard'].includes(me.state);
  if (busy) return inp;
  if (ai.wait > 0) { ai.wait--; return inp; }
  // reaksi pertahanan: lawan sedang menyerang (startup terlihat)
  const threat = seen.mv && (seen.state === 'attack' || seen.state === 'skill' || seen.state === 'charge') && seen.t <= (seen.mv.s + seen.mv.a) && Math.abs(seen.x - me.x) <= seen.mv.reach + 0.8;
  if (threat && rng() > D.mistake) {
    const r = rng();
    if (r < S.parry) { ai.hold = { i: { guard: true }, n: 14 }; inp.guard = true; return inp; }
    if (r < S.parry + S.dodge && me.stamina > 25) { ai.pulse = { k: 'dodge', n: 1, x: -dir }; inp.dodge = true; inp.x = -dir; return inp; }
    if (r < S.parry + S.dodge + S.guard) { ai.hold = { i: { guard: true }, n: 22 }; inp.guard = true; return inp; }
  }
  if (opp.state === 'blockstun' && rng() < 0.4) { inp.guard = false; }
  // penghukuman: lawan terpukul / recovery panjang / parried -> serang
  const punish = (opp.state === 'parried' || opp.state === 'knockdown' || (opp.state === 'attack' && opp.t > (opp.move ? opp.move.s + opp.move.a : 0)));
  const aim = S.spacing === undefined ? reach * 0.9 : Math.max(Math.min(S.spacing, 9), me.w.ranged ? S.spacing : reach * 0.8);
  // ultimate
  if (me.meter >= 100 && !me.noUlt && (punish || opp.state === 'hitstun' || rng() < 0.01) && dist < 4) { inp.ult = true; return inp; }
  ai.think--; if (ai.think > 0 && !punish) { // gerak halus antar keputusan
    if (me.w.ranged ? dist < aim - 0.5 : dist > reach * 0.9 && rng() < S.approach) inp.x = me.w.ranged ? -dir : dir; return inp; }
  ai.think = 5 + Math.floor(rng() * 6);
  const canHit = dist <= reach * 0.95 && opp.y < 1.2;
  const chars = CHARACTERS[me.charKey];
  if (me.w.ranged) {
    if (dist < 2.4 && rng() < 0.6) { if (me.cd.s2 <= 0 && me.charKey === 'TONY') { inp.s2 = true; return inp; } inp.x = -dir; inp.dash = rng() < 0.3; if (inp.dash) inp.x = -dir; return inp; }
    if (me.cd.s1 <= 0 && rng() < S.skill) { inp.s1 = true; return inp; }
    if (rng() < S.atkRate) { if (rng() < 0.4) { ai.hold = { i: { heavy: true }, n: 20 + Math.floor(rng() * 30) }; inp.heavy = true; } else inp.light = true; }
    else inp.x = dist > aim + 1 ? dir : 0;
    return inp;
  }
  if (canHit && (rng() < S.atkRate || punish)) {
    if (me.cd.ws <= 0 && rng() < S.skill * 0.5) { inp.ws = true; return inp; }
    if (me.cd.s1 <= 0 && rng() < S.skill * 0.5) { inp.s1 = true; return inp; }
    if (me.cd.s2 <= 0 && rng() < S.skill * 0.35) { inp.s2 = true; return inp; }
    if (S.preferHeavy && rng() < S.preferHeavy) inp.heavy = true;
    else { ai.pulse = { k: 'light', n: 1 }; inp.light = true; if (rng() < 0.5 * phaseMul) ai.hold = { i: { light: false }, n: 7 + Math.floor(rng() * 6) }; }
    return inp;
  }
  if (!canHit) {
    // proyektil/skill dari jauh
    if (dist > 3 && me.cd.s1 <= 0 && ['projectile', 'dashSlash'].includes(require_kind(me, 's1')) && rng() < S.skill * 0.4) { inp.s1 = true; return inp; }
    if (dist > aim && rng() < S.approach) { inp.x = dir; if (dist > 4 && rng() < 0.08 && me.stamina > 40) inp.dash = true; }
    else if (dist < aim * 0.6 && rng() < 0.3) inp.x = -dir;
    else if (S.guard > 0.5 && rng() < 0.3) inp.guard = true;
    return inp;
  }
  if (dist < aim * 0.6 && rng() < 0.4) inp.x = -dir; else if (S.guard > 0.4 && rng() < 0.4) inp.guard = true;
  return inp;
}
import { SKILLS } from '../data/data.js';
function require_kind(me, slot) { const id = CHARACTERS[me.charKey].skills[slot === 's1' ? 0 : 1]; return SKILLS[id].kind; }
