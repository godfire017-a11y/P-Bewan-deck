// SIM: simulasi pertarungan deterministik 60 Hz. Tidak menyentuh DOM/Three.js.
// Dipakai oleh klien (render) dan server (authoritative). Input -> step() -> state + events.
import { CHARACTERS, WEAPONS, SKILLS, MOVE_TEMPLATES, STAGES, RULES, deriveStats } from '../data/data.js';

export function makeRng(seed) {
  let a = seed >>> 0;
  const f = () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  f.state = () => a; return f;
}
const BASE_DMG = 60;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const NEUTRAL = new Set(['idle', 'walk', 'crouch', 'jump']);
export const EMPTY_INPUT = Object.freeze({ x: 0, up: false, down: false, light: false, heavy: false, guard: false, dodge: false, dash: false, s1: false, s2: false, ws: false, ult: false });

/* ----------------------------------------------------------- moveset dari data */
export function buildMoveset(charKey, weaponName) {
  const ch = CHARACTERS[charKey], w = WEAPONS[weaponName], st = deriveStats(ch);
  const moves = {};
  for (const [id, t] of Object.entries(MOVE_TEMPLATES)) {
    const o = Object.assign({}, t, (w.o && w.o[id]) || {});
    const sp = w.spd * st.speedMul;
    const m = {
      id, lv: o.lv, y: o.y, air: !!o.air, spike: !!o.spike, launch: o.launch || 0, knock: !!o.knock, armor: o.armor || 0, guardPierce: o.guardPierce || 0,
      s: Math.max(2, Math.round(o.s / sp)), a: o.a, r: Math.max(4, Math.round(o.r * w.rec / sp)),
      dmg: BASE_DMG * o.d * w.dmg * st.atkMul,
      reach: w.reach, kb: o.kb, hs: Math.min(RULES.combo.maxStun, Math.round(o.hs * w.stun * st.stunMul)), bs: o.bs,
      lunge: o.lunge || 0, back: o.back || 0,
    };
    if (w.minReach) m.minReach = w.minReach;
    moves[id] = m;
  }
  return { moves, combo: w.combo, weapon: w };
}
export function listCombos(charKey, weaponName) {
  const w = WEAPONS[weaponName], c = w.combo, ch = CHARACTERS[charKey];
  const out = [`Light chain: ${c.light.join(' > ')}  (tekan Light berturut-turut)`, `Heavy: ${c.heavy}`,
    `Light + Heavy: ${c.light.slice(0, 2).join(' > ')} > Heavy`, 'Atas + Light: HIGH (serangan tinggi)', 'Bawah + Light: CROUCH (serangan rendah)',
    'Maju + Light: FWD (menerjang)', 'Mundur + Light: BACK', 'Bawah + Heavy: LAUNCH lalu lompat + Light/Heavy (air follow-up)',
    'Dash + Light: DASH attack', 'Dodge/Parry sempurna + Light: COUNTER', `Weapon skill (${SKILLS[w.skill].name}) > Light > Heavy`];
  const [a, b] = ch.skills; out.push(`${SKILLS[a].name} > ${SKILLS[b].name}: kombo skill ${ch.name}`);
  return out;
}

/* ----------------------------------------------------------- pembuatan */
export function createFighter(idx, charKey, weaponName, opts = {}) {
  const ch = CHARACTERS[charKey]; if (!ch) throw new Error('Karakter tidak dikenal: ' + charKey);
  if (!ch.weapons.includes(weaponName)) weaponName = ch.defaultWeapon;   // kompatibilitas senjata
  const st = deriveStats(ch), ms = buildMoveset(charKey, weaponName);
  const hpMul = opts.hpMul || 1;
  return {
    idx, charKey, weaponName, st, ms, name: ch.name, w: ms.weapon,
    x: 0, y: 0, vx: 0, vy: 0, face: idx === 0 ? 1 : -1, onGround: true, jumps: 0,
    maxHp: Math.round(st.maxHp * hpMul), hp: Math.round(st.maxHp * hpMul), stamina: RULES.stamina.max, meter: 0, poise: st.poise * 0.5,
    state: 'idle', t: 0, move: null, skill: null, connected: false, hitDone: false, comboIdx: 0, chainBuf: 0,
    cd: { s1: 0, s2: 0, ws: 0, dodge: 0, dash: 0 }, buf: { light: 0, heavy: 0, ws: 0, s1: 0, s2: 0, ult: 0, dodge: 0, dash: 0 },
    prev: Object.assign({}, EMPTY_INPUT), guardT: 999, parryCd: 0, counterWin: 0, counterKind: null, crouch: false,
    hitstun: 0, invuln: 0, ccImm: 0, comboTaken: 0, comboDealt: 0, lastComboDealt: 0, slow: 0, slowF: 0, buff: null, shield: 0, shieldT: 0, charge: 0,
    dodgeDir: 0, dodgeHit: false, dashDir: 0, speedBoost: 0, stance: 0, dmgMulMod: 1, defMod: 1, spdMod: 1, noUlt: !!opts.noUlt,
    stats: { dealt: 0, taken: 0, hits: 0, blocks: 0, parries: 0, dodges: 0 }, kd: false, armorLeft: 0, pending: null,
  };
}
export function createSim(cfg) {
  const stage = STAGES[cfg.stage || 'shadowTemple'];
  const sim = {
    tick: 0, freeze: 0, stage: cfg.stage || 'shadowTemple', half: stage.width, events: [], projectiles: [], traps: [], rng: makeRng(cfg.seed || 1337),
    mode: cfg.mode || 'versus', training: !!cfg.training, mods: cfg.mods || {}, nextId: 1,
    f: [createFighter(0, cfg.p1.char, cfg.p1.weapon, { hpMul: cfg.p1.hpMul, noUlt: cfg.noUlt }), createFighter(1, cfg.p2.char, cfg.p2.weapon, { hpMul: cfg.p2.hpMul, noUlt: cfg.noUlt })],
    round: { state: 'intro', no: 1, wins: [0, 0], t: 0, timer: RULES.roundTime * 60, sudden: false, winner: -1, matchWinner: -1, reason: '', log: [] },
    result: null,
  };
  if (cfg.mods) for (const f of sim.f) { const M = cfg.mods; if (M.hp) f.maxHp = f.hp = Math.round(f.maxHp * M.hp); if (M.spd) f.spdMod = M.spd; }
  resetRound(sim); if (cfg.startHpRatio) sim.f[0].hp = Math.max(1, Math.round(sim.f[0].maxHp * cfg.startHpRatio));
  sim.round.state = sim.training ? 'fight' : 'intro'; return sim;
}
function resetRound(sim) {
  const [a, b] = sim.f;
  for (const f of sim.f) {
    f.hp = f.maxHp; f.stamina = RULES.stamina.max; f.meter = Math.min(f.meter, 50); f.state = 'idle'; f.t = 0; f.move = null; f.skill = null; f.vx = f.vy = 0; f.y = 0; f.onGround = true; f.jumps = 0;
    f.hitstun = 0; f.invuln = 0; f.ccImm = 0; f.comboTaken = 0; f.comboDealt = 0; f.slow = f.slowF = 0; f.buff = null; f.shield = f.shieldT = 0; f.charge = 0; f.counterWin = 0; f.stance = 0;
    f.cd = { s1: 0, s2: 0, ws: 0, dodge: 0, dash: 0 }; f.poise = f.st.poise * 0.5; f.parryCd = 0; f.crouch = false; f.pending = null; f.speedBoost = 0;
  }
  a.x = -2.2; b.x = 2.2; a.face = 1; b.face = -1; sim.projectiles.length = 0; sim.traps.length = 0;
  const r = sim.round; r.timer = (r.sudden ? RULES.suddenDeathTime : RULES.roundTime) * 60; r.t = 0;
}
export function surrender(sim, idx) { endMatch(sim, 1 - idx, 'surrender'); }
function endMatch(sim, w, reason) {
  const r = sim.round; r.state = 'matchEnd'; r.matchWinner = w; r.reason = reason; r.t = 0;
  sim.result = { winner: w, reason, wins: r.wins.slice(), rounds: r.no, stats: sim.f.map((f) => f.stats) }; sim.events.push({ t: 'match', winner: w, reason });
}
function endRound(sim, w, reason) {
  const r = sim.round; r.state = 'roundEnd'; r.winner = w; r.t = 0; r.reason = reason; r.wins[w]++; r.log.push({ no: r.no, winner: w, reason });
  sim.events.push({ t: 'roundEnd', winner: w, reason });
  const loser = sim.f[1 - w]; if (loser.hp <= 0) { loser.state = 'dead'; loser.t = 0; }
  sim.f[w].state = sim.f[w].state === 'dead' ? 'dead' : 'victory';
}

/* ----------------------------------------------------------- util geometri */
const hurt = (f) => ({ x0: f.x - f.st.width / 2, x1: f.x + f.st.width / 2, y0: f.y, y1: f.y + (f.crouch || f.state === 'knockdown' ? 1.0 : f.st.height) });
function overlap(box, f) { const h = hurt(f); return box.x1 >= h.x0 && box.x0 <= h.x1 && box.y1 >= h.y0 && box.y0 <= h.y1; }
function atkBox(f, move) {
  const reach = move.reach, w = f.st.width / 2;
  const x0 = f.face > 0 ? f.x + w * 0.3 : f.x - w * 0.3 - reach, x1 = f.face > 0 ? f.x + w * 0.3 + reach : f.x - w * 0.3;
  return { x0, x1, y0: f.y + move.y[0], y1: f.y + move.y[1] };
}
function emit(sim, e) { sim.events.push(e); }

/* ----------------------------------------------------------- penerimaan serangan (satu pintu) */
// hd: {dmg, kb, hs, bs, lv, launch, knock, spike, guardPierce, guardBreak, stun, slow, slowF, pierceGuard, proj, src(f idx), kind}
function applyHit(sim, atk, def, hd) {
  if (def.state === 'dead' || sim.round.state !== 'fight') return 'none';
  const R = RULES, dir = Math.sign(def.x - atk.x) || atk.face;
  // 1. kebal / dodge
  if (def.invuln > 0 || def.state === 'getup' || (def.state === 'dodge' && def.t <= def.st.dodgeI)) {
    if (def.state === 'dodge' && !def.dodgeHit && def.t <= R.perfectDodge.window) {
      def.dodgeHit = true; def.counterWin = R.perfectDodge.counterWindow; def.counterKind = 'dodge'; def.meter = Math.min(100, def.meter + R.perfectDodge.meter); def.stats.dodges++;
      if (def.charKey === 'STARK') def.speedBoost = 120;
      emit(sim, { t: 'perfectDodge', f: def.idx, x: def.x, y: def.y + 1 });
    } else emit(sim, { t: 'whiff', f: def.idx });
    return 'dodged';
  }
  // 2. counter stance (Iaido)
  if (def.state === 'skill' && def.skill && def.skill.kind === 'counterStance' && def.stance > 0 && !hd.proj) {
    def.stance = 0; def.skill = null; startMove(def, def.ms.moves.COUNTER); def.face = Math.sign(atk.x - def.x) || def.face;
    atk.hitstun = 0; setState(atk, 'parried', R.parry.stunFrames); emit(sim, { t: 'counterStance', f: def.idx, x: def.x, y: def.y + 1 }); return 'countered';
  }
  const facing = (atk.x - def.x) * def.face > 0 || hd.proj && (hd.px - def.x) * def.face > 0;
  const guarding = def.state === 'guard' || def.state === 'blockstun';
  // 3. parry
  if (def.state === 'guard' && def.guardT <= R.parry.window && def.parryCd <= 0 && facing && !hd.guardBreak && !hd.unparryable) {
    def.parryCd = R.parry.cd; def.counterWin = R.parry.counterWindow; def.counterKind = 'parry'; def.stats.parries++; def.meter = Math.min(100, def.meter + 10);
    if (!hd.proj) { setState(atk, 'parried', R.parry.stunFrames); atk.move = null; atk.skill = null; }
    emit(sim, { t: 'parry', f: def.idx, x: (atk.x + def.x) / 2, y: def.y + 1.1 }); sim.freeze = Math.max(sim.freeze, 6); return 'parried';
  }
  // 4. block
  const crouchG = def.crouch, lvOk = hd.lv === 'mid' || (hd.lv === 'high' && !crouchG) || (hd.lv === 'low' && crouchG) || !hd.lv;
  if (guarding && facing && lvOk && !hd.guardBreak && def.stamina > 0) {
    let thru = R.guard.chip + (hd.guardPierce || 0) + (hd.pierceGuard || 0);
    const dmg = hd.dmg * thru * def.st.dmgTaken * def.defMod;
    def.hp = Math.max(0, def.hp - dmg); def.stamina -= hd.dmg * R.guard.staminaPerDmg; def.stats.blocks++; atk.stats.dealt += dmg; def.stats.taken += dmg;
    def.vx = dir * hd.kb * 0.6; atk.vx = -dir * hd.kb * 0.3; if (def.state === 'guard') setState(def, 'blockstun', hd.bs); else def.t = 0, def.hitstun = hd.bs;
    def.hitstun = hd.bs; atk.meter = Math.min(100, atk.meter + R.meter.onBlock); def.meter = Math.min(100, def.meter + R.meter.onBlock);
    emit(sim, { t: 'block', f: def.idx, x: def.x - dir * 0.3, y: def.y + 1.1, dmg }); sim.freeze = Math.max(sim.freeze, 2);
    if (def.stamina <= 0) { def.stamina = 0; breakGuard(sim, def); }
    checkKo(sim, def, atk); return 'blocked';
  }
  // 5. kena
  let scale = R.combo.scale[Math.min(def.comboTaken, R.combo.scale.length - 1)];
  let dmg = hd.dmg * scale * def.st.dmgTaken * def.defMod * (atk.buff ? atk.buff.atk : 1) * (sim.mods.dmg || 1);
  if (atk.charKey === 'APCB' && def.slowF > 0) dmg *= 1.08;                      // passive Hex Mark
  if (atk.charKey === 'ZUKI' && atk.hp < atk.maxHp * 0.3) { /* Second Wind diterapkan di kecepatan */ }
  if (atk.charKey === 'TONY' && hd.proj) dmg *= 1 + Math.min(0.25, Math.abs(hd.px - def.x) / 9 * 0.25);   // Eagle Eye
  if (sim.mods.enemyDef && def.idx === 1) dmg *= sim.mods.enemyDef;
  if (def.shield > 0) { const ab = Math.min(def.shield, dmg); def.shield -= ab; dmg -= ab; if (def.shield <= 0) def.shieldT = 0; }
  def.hp = Math.max(0, def.hp - dmg); def.stats.taken += dmg; atk.stats.dealt += dmg; atk.stats.hits++;
  def.meter = Math.min(100, def.meter + dmg * R.meter.onHurt); if (!atk.noUlt) atk.meter = Math.min(100, atk.meter + dmg * R.meter.onHit);
  atk.comboDealt++; if (atk.charKey === 'MASHU' && atk.comboDealt === 3) atk.meter = Math.min(100, atk.meter + 5);
  def.comboTaken++; def.poise = Math.max(0, def.poise - dmg * 0.25);
  if (sim.round.sudden && dmg > 0) { endRound(sim, atk.idx, 'sudden'); }
  // armor / poise: serangan berat tidak terputus
  const armored = def.state === 'attack' && def.move && def.move.armor > 0 && def.t < def.move.s + def.move.a && def.armorLeft > 0;
  const titanArmor = def.charKey === 'TITAN' && def.state === 'attack' && def.move && def.move.id === 'H' && def.t < def.move.s + def.move.a && def.poise > 0;
  const heavyHit = hd.dmg >= 100;
  if ((armored || titanArmor) && !hd.guardBreak && !hd.launch && !hd.stun) { if (armored) def.armorLeft--; def.vx = dir * hd.kb * 0.15; emit(sim, { t: 'hit', f: def.idx, x: def.x, y: def.y + 1.1, dmg, armor: true, heavy: heavyHit }); sim.freeze = Math.max(sim.freeze, 2); checkKo(sim, def, atk); return 'armor'; }
  // stun & anti stun-lock
  let hs = Math.round(hd.hs * Math.pow(0.92, Math.min(def.comboTaken - 1, 6)));
  if (hd.stun) { if (def.ccImm > 0) hs = 12; else { hs = Math.min(R.combo.maxStun, Math.round(hd.stun * atk.st.stunMul)); def.ccImm = R.combo.ccImmunity + hs; emit(sim, { t: 'stun', f: def.idx, frames: hs, x: def.x, y: def.y + 1.8 }); } }
  hs = Math.max(8, hs);
  if (hd.slow) { def.slow = hd.slow; def.slowF = hd.slowF || 120; }
  def.armorLeft = 0;
  if (def.state === 'attack' || def.state === 'skill' || def.state === 'charge') { def.move = null; def.skill = null; def.charge = 0; def.pending = null; }
  def.vx = dir * hd.kb; def.face = -dir; def.crouch = false;
  if (hd.launch) { def.vy = hd.launch; def.onGround = false; def.y += 0.05; setState(def, 'hitstun', 60); def.kd = false; }
  else if ((hd.knock || hd.spike) && def.hp > 0) { def.kd = true; setState(def, 'hitstun', hs); }
  else { def.kd = false; setState(def, 'hitstun', hs); }
  def.hitstun = hs;
  if (hd.spike) { def.vy = -9; }
  atk.connected = true; atk.vx += -dir * hd.kb * 0.15;
  if (def.comboTaken >= R.combo.maxHitsBeforeBreak) { def.invuln = R.combo.breakInvuln; def.comboTaken = 0; def.kd = true; def.vx = dir * 5; emit(sim, { t: 'comboBreak', f: def.idx }); }
  emit(sim, { t: 'hit', f: def.idx, x: def.x, y: def.y + 1.1, dmg, heavy: heavyHit, weapon: atk.weaponName, kind: hd.kind || 'melee', combo: atk.comboDealt, dir });
  sim.freeze = Math.max(sim.freeze, heavyHit ? 5 : 3);
  checkKo(sim, def, atk); return 'hit';
}
function breakGuard(sim, f) { setState(f, 'hitstun', 50); f.hitstun = 50; f.kd = false; f.state = 'hitstun'; emit(sim, { t: 'guardBreak', f: f.idx, x: f.x, y: f.y + 1.2 }); }
function checkKo(sim, def, atk) { if (def.hp <= 0 && sim.round.state === 'fight' && !sim.training) { def.state = 'dead'; def.t = 0; def.vx = Math.sign(def.x - atk.x) * 3; endRound(sim, atk.idx, 'ko'); emit(sim, { t: 'ko', f: def.idx }); } else if (def.hp <= 0 && sim.training) def.hp = def.maxHp; }
function setState(f, s, frames) { f.state = s; f.t = 0; f.stateLen = frames || 0; }

/* ----------------------------------------------------------- aksi */
function startMove(f, move) { f.state = 'attack'; f.move = move; f.t = 0; f.connected = false; f.hitDone = false; f.armorLeft = move.armor || 0; f.chainBuf = 0; f.skill = null; if (f.charKey === 'ZUKI' && f.hp < f.maxHp * 0.3) f.t = 1; }
function fireProjectile(sim, f, o) {
  sim.projectiles.push({ id: sim.nextId++, owner: f.idx, x: f.x + f.face * 0.6, y: f.y + (f.crouch ? 0.7 : 1.2) + (o.dy || 0), vx: f.face * o.speed * Math.cos(o.ang || 0), vy: o.speed * Math.sin(o.ang || 0) * 0.35, life: o.life, dmg: o.dmg, hs: o.hs || 18, bs: 12, kb: o.kb || 2, stun: o.stun || 0, pierceGuard: o.pierceGuard || 0, color: o.color, kind: o.kindName || 'arrow', r: 0.25, ox: f.x });
}
function moveSpeed(f) { return f.st.walk * (f.slowF > 0 ? f.slow : 1) * (f.speedBoost > 0 ? 1.25 : 1) * f.spdMod; }

function chooseAttack(f, inp, opp) {
  const ms = f.ms, c = f.w.combo, dx = (inp.x * f.face);
  const air = !f.onGround;
  // bow: jarak dekat = serangan lemah & lambat
  if (f.w.ranged && f.onGround && Math.abs(opp.x - f.x) < f.w.minReach) return { kind: 'bash' };
  if (f.counterWin > 0 && (inp.light || f.buf.light > 0)) { f.counterWin = 0; return { move: ms.moves.COUNTER }; }
  return null;
}

function tryAttackInputs(sim, f, inp, opp) {
  const ms = f.ms, c = f.w.combo, fwd = inp.x * f.face > 0.3, back = inp.x * f.face < -0.3;
  const wantL = f.buf.light > 0, wantH = f.buf.heavy > 0;
  if (!wantL && !wantH) return false;
  let mv = null;
  if (f.counterWin > 0 && wantL) { mv = ms.moves.COUNTER; f.counterWin = 0; }
  else if (!f.onGround) mv = wantH ? ms.moves.AIRH : ms.moves.AIR;
  else if (f.w.ranged) { f.buf.light = f.buf.heavy = 0; return beginShot(sim, f, wantH, opp); }
  else if (wantH && inp.down) mv = ms.moves.LAUNCH;
  else if (wantL && inp.down) mv = ms.moves.CROUCH;
  else if (wantL && inp.up) mv = ms.moves.HIGH;
  else if (wantL && f.dashDir && f.cd.dash > 8) mv = ms.moves.DASH;
  else if (wantL && fwd && f.state !== 'attack') mv = ms.moves.FWD;
  else if (wantL && back) mv = ms.moves.BACK;
  else if (wantH) mv = ms.moves[c.heavy];
  else { f.comboIdx = f.comboIdx % c.light.length; mv = ms.moves[c.light[f.comboIdx]]; f.comboIdx = (f.comboIdx + 1) % c.light.length; }
  f.buf.light = f.buf.heavy = 0;
  if (mv.minReach && Math.abs(opp.x - f.x) < mv.minReach && mv.id !== 'LAUNCH') { mv = Object.assign({}, mv, { dmg: mv.dmg * 0.7 }); }  // tombak terlalu dekat: lemah
  if (mv.air && !f.onGround) { startMove(f, mv); return true; }
  if (f.crouch && f.state !== 'attack') { /* serangan jongkok tetap jongkok */ }
  startMove(f, mv); return true;
}
function beginShot(sim, f, heavy, opp) {
  const close = Math.abs(opp.x - f.x) < f.w.minReach;
  const m = { id: heavy ? 'SHOT_H' : 'SHOT_L', s: Math.round((heavy ? 14 : 10) / (f.w.spd * f.st.speedMul)) + (close ? 10 : 0), a: 1, r: Math.round((heavy ? 20 : 12) * f.w.rec), shot: true, heavy, dmg: BASE_DMG * f.w.dmg * f.st.atkMul * (heavy ? 1.3 : 0.7), reach: 0, y: [0, 0], armor: 0, hs: 20, bs: 12, lv: 'mid', kb: 2 };
  startMove(f, m); f.charge = 0; f.state = heavy ? 'charge' : 'attack'; f.hitDone = false; return true;
}
function startSkill(sim, f, key, opp) {
  const id = key === 'ws' ? f.w.skill : key === 'ult' ? CHARACTERS[f.charKey].ult : CHARACTERS[f.charKey].skills[key === 's1' ? 0 : 1];
  const sk = SKILLS[id]; if (!sk) return false;
  if (key === 'ult') { if (f.meter < 100 || f.noUlt || sim.mods.noUlt) return false; f.meter = 0; }
  else { if (f.cd[key] > 0) return false; f.cd[key] = Math.round(sk.cd * (sim.training ? 0.25 : 1)); }
  f.state = 'skill'; f.skill = sk; f.skillId = id; f.t = 0; f.move = null; f.hitDone = false; f.connected = false; f.stateLen = sk.s + (sk.rec || 0); f.skillFired = false; f.skHits = 0;
  if (sk.kind === 'counterStance') f.stance = sk.frames;
  emit(sim, { t: 'telegraph', f: f.idx, skill: id, frames: sk.s, ult: !!sk.ult, color: sk.color });
  return true;
}
function skillEffect(sim, f, opp) {
  const sk = f.skill, am = f.st.atkMul * (f.buff ? f.buff.atk : 1), dmg = sk.dmg * am;
  const hdBase = { kb: 3, hs: 24, bs: 14, lv: 'mid', kind: 'skill' };
  switch (sk.kind) {
    case 'projectile': {
      const n = sk.count || 1;
      for (let i = 0; i < n; i++) { const ang = n === 1 ? 0 : (i / (n - 1) - 0.5) * (sk.spread || 0.3) * 2; fireProjectile(sim, f, { speed: sk.speed, life: sk.life, dmg: dmg, ang, stun: sk.stun, pierceGuard: sk.pierceGuard, color: sk.color, kindName: sk.name }); }
      break; }
    case 'dashSlash': f.dashSkill = { left: sk.hits * 5, per: dmg / sk.hits, hits: sk.hits, dist: sk.dist, n: 0 }; f.vx = f.face * sk.dist / (sk.hits * 5 / 60); break;
    case 'teleport': {
      if (sk.dist > 0) { const side = Math.sign(opp.x - f.x) || f.face; f.x = clamp(opp.x + side * 1.1, -sim.half + RULES.arenaPad, sim.half - RULES.arenaPad); f.face = -side; emit(sim, { t: 'teleport', f: f.idx, x: f.x, y: f.y + 1 }); }
      else { const nx = clamp(f.x + f.face * sk.dist, -sim.half + RULES.arenaPad, sim.half - RULES.arenaPad); f.vx = (nx - f.x) * 5; f.vy = 5; f.onGround = false; if (sk.shoot) fireProjectile(sim, f, { speed: sk.speed, life: sk.life, dmg, stun: sk.stun, color: sk.color, kindName: sk.name, dy: 0.2 }); }
      break; }
    case 'area': {
      const r = sk.radius; const dx = Math.abs(opp.x - f.x);
      emit(sim, { t: 'area', f: f.idx, x: f.x, r, color: sk.color });
      if (dx <= r && (!sk.groundOnly || opp.y < 0.4)) applyHit(sim, f, opp, Object.assign({}, hdBase, { dmg, stun: sk.stun, slow: sk.slow, slowF: sk.slowF, hs: 30, kb: 4, knock: sk.ult }));
      break; }
    case 'stunAttack': {
      const box = { x0: f.face > 0 ? f.x : f.x - sk.reach, x1: f.face > 0 ? f.x + sk.reach : f.x, y0: f.y, y1: f.y + 2 };
      if (overlap(box, opp)) applyHit(sim, f, opp, Object.assign({}, hdBase, { dmg, stun: sk.stun, guardBreak: !!sk.guardBreak }));
      break; }
    case 'launcher': {
      const box = { x0: f.face > 0 ? f.x : f.x - 1.6, x1: f.face > 0 ? f.x + 1.6 : f.x, y0: f.y, y1: f.y + 2 };
      if (overlap(box, opp)) applyHit(sim, f, opp, Object.assign({}, hdBase, { dmg, launch: 8, hs: 40, lv: 'low' })); break; }
    case 'buff': f.buff = { atk: sk.atk, t: sk.frames }; f.defMod = sk.def; break;
    case 'shield': f.shield = sk.absorb; f.shieldT = sk.frames; break;
    case 'trap': sim.traps.push({ id: sim.nextId++, owner: f.idx, x: clamp(f.x + f.face * 1.6, -sim.half + 0.5, sim.half - 0.5), life: sk.life, slow: sk.slow, slowF: sk.slowF, dmg, color: sk.color }); break;
    case 'counterStance': break;
  }
}

function beginDodge(sim, f, inp) {
  if (f.cd.dodge > 0 || f.stamina < RULES.stamina.dodge || !f.onGround) return false;
  f.stamina -= RULES.stamina.dodge; f.cd.dodge = 40; const d = inp.x * f.face; f.dodgeDir = d > 0.3 ? 1 : -1; f.dodgeHit = false;
  setState(f, 'dodge', 22); f.vx = f.dodgeDir * f.face * f.st.dashDist * 3.2; f.crouch = false; emit(sim, { t: 'dodge', f: f.idx, x: f.x, y: f.y + 1 }); return true;
}
function beginDash(sim, f, inp) {
  if (f.cd.dash > 0 || f.stamina < RULES.stamina.dash || !f.onGround) return false;
  f.stamina -= RULES.stamina.dash; f.cd.dash = 30; const d = inp.x * f.face; f.dashDir = d < -0.3 ? -1 : 1;
  setState(f, 'dash', 14); f.vx = f.dashDir * f.face * f.st.dashDist * 4.2; emit(sim, { t: 'dash', f: f.idx, x: f.x, y: f.y }); return true;
}

/* ----------------------------------------------------------- update per fighter */
function updateFighter(sim, f, inp, opp) {
  inp = inp || EMPTY_INPUT;
  const R = RULES, dt = 1 / 60;
  // timer
  for (const k in f.cd) if (f.cd[k] > 0) f.cd[k]--;
  for (const k in f.buf) if (f.buf[k] > 0) f.buf[k]--;
  if (f.invuln > 0) f.invuln--; if (f.ccImm > 0) f.ccImm--; if (f.parryCd > 0) f.parryCd--; if (f.counterWin > 0) f.counterWin--; if (f.speedBoost > 0) f.speedBoost--;
  if (f.slowF > 0) f.slowF--; if (f.buff && --f.buff.t <= 0) { f.buff = null; f.defMod = 1; } if (f.shieldT > 0 && --f.shieldT <= 0) f.shield = 0; if (f.stance > 0) f.stance--;
  if (f.state !== 'guard' && f.state !== 'blockstun') f.guardT = 999;
  if (f.state !== 'attack' && f.state !== 'skill' && f.state !== 'hitstun' && f.state !== 'dodge' && f.state !== 'dash') f.stamina = Math.min(R.stamina.max, f.stamina + R.stamina.regen * (f.state === 'guard' ? 0.4 : 1));
  f.poise = Math.min(f.st.poise * 0.5, f.poise + 0.03);
  // buffer (tombol baru ditekan)
  const press = (k) => inp[k] && !f.prev[k];
  if (press('light')) f.buf.light = R.bufferFrames; if (press('heavy')) f.buf.heavy = R.bufferFrames; if (press('ws')) f.buf.ws = R.bufferFrames;
  if (press('s1')) f.buf.s1 = R.bufferFrames; if (press('s2')) f.buf.s2 = R.bufferFrames; if (press('ult')) f.buf.ult = R.bufferFrames;
  if (press('dodge')) f.buf.dodge = R.bufferFrames; if (press('dash')) f.buf.dash = R.bufferFrames;
  const releasedHeavy = !inp.heavy && f.prev.heavy;
  const canAct = f.state === 'idle' || f.state === 'walk' || f.state === 'crouch' || f.state === 'jump' || f.state === 'guard';
  // aksi dari netral
  if (sim.round.state === 'fight' && sim.freeze <= 0 || (f.state === 'charge')) {
    if (canAct || f.state === 'charge') {
      if (canAct) {
        if (f.buf.dodge > 0 && beginDodge(sim, f, inp)) { f.buf.dodge = 0; }
        else if (f.buf.dash > 0 && beginDash(sim, f, inp)) { f.buf.dash = 0; }
        else if (f.buf.ult > 0 && startSkill(sim, f, 'ult', opp)) { f.buf.ult = 0; }
        else if (f.buf.s1 > 0 && startSkill(sim, f, 's1', opp)) { f.buf.s1 = 0; }
        else if (f.buf.s2 > 0 && startSkill(sim, f, 's2', opp)) { f.buf.s2 = 0; }
        else if (f.buf.ws > 0 && startSkill(sim, f, 'ws', opp)) { f.buf.ws = 0; }
        else if ((f.buf.light > 0 || f.buf.heavy > 0) && tryAttackInputs(sim, f, inp, opp)) { /* mulai serangan */ }
        else if (f.onGround) {
          if (inp.guard) { if (f.state !== 'guard') { setState(f, 'guard', 0); f.guardT = 0; } else f.guardT++; f.crouch = inp.down; }
          else {
            f.crouch = inp.down; const mv = f.crouch ? 0 : inp.x * moveSpeed(f);
            f.vx += (mv - f.vx) * 0.45; f.state = f.crouch ? 'crouch' : (Math.abs(mv) > 0.1 ? 'walk' : 'idle');
            if (inp.up && !f.crouch) { f.vy = R.jumpV; f.onGround = false; f.state = 'jump'; f.jumps = 1; emit(sim, { t: 'jump', f: f.idx, x: f.x }); }
          }
        }
      }
      if (f.state === 'guard' && !inp.guard) f.state = 'idle';
      if (!f.onGround) {                                     // di udara
        f.vx += (inp.x * moveSpeed(f) * 0.9 - f.vx) * 0.08;
        if (press('up') && f.jumps < 2 && CHARACTERS[f.charKey].doubleJump) { f.vy = R.jumpV * 0.9; f.jumps = 2; emit(sim, { t: 'jump', f: f.idx, x: f.x }); }
      }
    }
  }
  // state machine
  f.t++;
  switch (f.state) {
    case 'attack': {
      const m = f.move; if (!m) { f.state = 'idle'; break; }
      if (m.shot) {                                           // serangan jarak jauh (Bow)
        if (f.t === m.s && !f.hitDone) {
          f.hitDone = true; fireProjectile(sim, f, { speed: 14, life: 60, dmg: m.dmg, stun: 0, hs: m.heavy ? 26 : 18, color: f.w.trail, kindName: 'arrow', dy: 0 }); emit(sim, { t: 'shoot', f: f.idx });
        }
        if (f.t >= m.s + m.r) { f.state = 'idle'; f.move = null; }
        break;
      }
      const tot = m.s + m.a + m.r;
      if (f.t <= m.s + m.a && m.lunge) f.vx = f.face * m.lunge / ((m.s + m.a) / 60);
      if (m.back && f.t <= m.s) f.vx = -f.face * m.back / (m.s / 60);
      if (f.t === 1) emit(sim, { t: 'swing', f: f.idx, move: m.id, weapon: f.weaponName });
      if (f.t >= m.s && f.t < m.s + m.a && !f.hitDone && !(m.air && f.onGround && false)) {
        const box = atkBox(f, m);
        if (overlap(box, opp)) { f.hitDone = true; applyHit(sim, f, opp, { dmg: m.dmg, kb: m.kb, hs: m.hs, bs: m.bs, lv: m.lv, launch: m.launch, knock: m.knock, spike: m.spike, guardPierce: m.guardPierce, kind: 'melee' }); }
      }
      // chain / cancel: hanya jika terkonfirmasi (hit/block), jendela di recovery awal
      if (f.connected && f.t >= m.s + m.a && f.t < m.s + m.a + 12) {
        if (f.buf.heavy > 0 || f.buf.light > 0) { if (tryAttackInputs(sim, f, inp, opp)) break; }
        if (f.buf.ws > 0 && startSkill(sim, f, 'ws', opp)) { f.buf.ws = 0; break; }
        if (f.buf.s1 > 0 && startSkill(sim, f, 's1', opp)) { f.buf.s1 = 0; break; }
      }
      if (f.t >= tot) { f.state = 'idle'; f.move = null; if (!f.connected) f.comboIdx = 0; }
      break; }
    case 'charge': {
      const m = f.move; if (!m) { f.state = 'idle'; break; }
      if (inp.heavy && f.charge < 60 && f.t < 90) { f.charge++; f.vx *= 0.8; }
      else if (!f.hitDone) {
        f.hitDone = true; const c = f.charge / 60; const dmg = m.dmg * (0.55 + 0.9 * c) * (f.charge < 10 ? 0.7 : 1);
        fireProjectile(sim, f, { speed: 11 + c * 8, life: 70, dmg, hs: 22 + c * 12, kb: 2 + c * 3, pierceGuard: c > 0.9 ? 0.3 : 0, color: f.w.trail, kindName: 'arrow' }); emit(sim, { t: 'shoot', f: f.idx, charge: c });
        f.t = Math.max(m.s, 1); f.state = 'attack'; f.move = Object.assign({}, m, { s: 1, shot: true }); f.t = 2; f.hitDone = true;
      }
      break; }
    case 'skill': {
      const sk = f.skill; if (!sk) { f.state = 'idle'; break; }
      if (f.t === sk.s && !f.skillFired) { f.skillFired = true; skillEffect(sim, f, opp); }
      if (f.dashSkill) {
        const d = f.dashSkill; d.left--;
        if (d.left % 5 === 0 && d.n < d.hits) { d.n++; const box = { x0: f.x - 0.8, x1: f.x + 0.8, y0: f.y, y1: f.y + 2 }; box.x0 = f.face > 0 ? f.x - 0.3 : f.x - 1.3; box.x1 = f.face > 0 ? f.x + 1.3 : f.x + 0.3; if (overlap(box, opp)) applyHit(sim, f, opp, { dmg: d.per, kb: d.n === d.hits ? 4 : 0.5, hs: 14, bs: 10, lv: 'mid', knock: d.n === d.hits && d.hits > 1, kind: 'skill' }); emit(sim, { t: 'swing', f: f.idx, move: 'skillhit', weapon: f.weaponName }); }
        if (d.left <= 0) { f.dashSkill = null; f.vx = 0; }
      }
      if (f.state !== 'skill' || !f.skill) { f.dashSkill = null; break; }   // terparry/terputus di tengah skill
      if (f.t >= sk.s + (sk.rec || 0) + (sk.kind === 'dashSlash' ? sk.hits * 5 : 0)) { f.state = 'idle'; f.skill = null; f.stance = 0; f.dashSkill = null; }
      break; }
    case 'dodge': if (f.t >= 22) { f.state = 'idle'; f.vx = 0; } else f.vx *= 0.92; break;
    case 'dash': if (f.t >= 14) { f.state = 'idle'; f.vx = 0; } else f.vx *= 0.93; break;
    case 'blockstun': if (f.t >= f.hitstun) { f.state = inp.guard ? 'guard' : 'idle'; f.guardT = 999; } break;
    case 'parried': if (f.t >= RULES.parry.stunFrames) { f.state = 'idle'; } break;
    case 'hitstun': {
      if (f.onGround && f.t >= f.hitstun) {
        if (f.kd) { f.state = 'knockdown'; f.t = 0; f.kd = false; f.vx *= 0.3; emit(sim, { t: 'knockdown', f: f.idx, x: f.x }); } else { f.state = 'idle'; f.comboTaken = 0; opp.comboDealt = 0; }
      }
      break; }
    case 'knockdown': if (f.t >= 38) { f.state = 'getup'; f.t = 0; f.invuln = 24; f.comboTaken = 0; opp.comboDealt = 0; emit(sim, { t: 'getup', f: f.idx }); } break;
    case 'getup': if (f.t >= 24) { f.state = 'idle'; } break;
    case 'jump': case 'walk': case 'idle': case 'crouch': case 'guard': break;
    case 'dead': f.vx *= 0.9; break;
    case 'victory': f.vx *= 0.8; break;
  }
  if (f.state === 'idle' || f.state === 'walk') { if (!f.onGround) f.state = 'jump'; }
  if (f.state === 'jump' && f.onGround) f.state = 'idle';
  // hadap lawan di netral
  if ((f.state === 'idle' || f.state === 'walk' || f.state === 'crouch' || f.state === 'guard' || f.state === 'jump') && !(f.dashSkill)) f.face = Math.sign(opp.x - f.x) || f.face;
  // fisika
  if (!f.onGround) { f.vy -= R.gravity * dt; }
  f.x += f.vx * dt; f.y += f.vy * dt;
  if (f.y <= 0) { if (!f.onGround) { f.onGround = true; if (f.vy < -3) emit(sim, { t: 'land', f: f.idx, x: f.x }); } f.y = 0; f.vy = 0; f.jumps = 0; if (f.state === 'hitstun' && f.kd === false && f.hitstun > 0 && f.t < f.hitstun) { /* tetap hitstun sampai habis */ } }
  if (f.onGround && f.state !== 'dodge' && f.state !== 'dash' && f.state !== 'attack' && f.state !== 'skill') f.vx *= (f.state === 'hitstun' ? 0.9 : 1);
  f.x = clamp(f.x, -sim.half + 0.4, sim.half - 0.4);
  f.prev = Object.assign({}, inp); f.prev.up = !!inp.up;
}

/* ----------------------------------------------------------- proyektil & trap */
function updateProjectiles(sim) {
  const dt = 1 / 60;
  for (let i = sim.projectiles.length - 1; i >= 0; i--) {
    const p = sim.projectiles[i]; p.x += p.vx * dt; p.y += p.vy * dt; p.life--;
    const own = sim.f[p.owner], tgt = sim.f[1 - p.owner];
    const box = { x0: p.x - p.r, x1: p.x + p.r, y0: p.y - 0.2, y1: p.y + 0.2 };
    let gone = p.life <= 0 || Math.abs(p.x) > sim.half + 2 || p.y < 0;
    if (!gone && overlap(box, tgt) && tgt.state !== 'dead') {
      const res = applyHit(sim, own, tgt, { dmg: p.dmg, kb: p.kb, hs: p.hs, bs: p.bs, lv: 'mid', stun: p.stun, pierceGuard: p.pierceGuard, proj: true, px: p.x, kind: 'projectile' });
      if (res !== 'dodged') gone = true; else if (res === 'dodged' && p.life > 3) { /* melewati lawan */ }
    }
    if (gone) sim.projectiles.splice(i, 1);
  }
  for (let i = sim.traps.length - 1; i >= 0; i--) {
    const t = sim.traps[i]; t.life--; const tgt = sim.f[1 - t.owner];
    if (Math.abs(tgt.x - t.x) < 0.7 && tgt.y < 0.4 && tgt.state !== 'dead' && tgt.invuln <= 0 && tgt.state !== 'getup') {
      tgt.slow = t.slow; tgt.slowF = t.slowF; tgt.hp = Math.max(0, tgt.hp - t.dmg * tgt.st.dmgTaken); emit(sim, { t: 'trap', f: tgt.idx, x: t.x, color: t.color }); t.life = 0; checkKo(sim, tgt, sim.f[t.owner]);
    }
    if (t.life <= 0) sim.traps.splice(i, 1);
  }
}
function separate(sim) {
  const [a, b] = sim.f; if (a.state === 'dead' || b.state === 'dead') return;
  if (a.y > 1.2 || b.y > 1.2) return;                       // lompat melewati lawan
  const d = b.x - a.x, minD = RULES.minSeparation, s = Math.sign(d) || (a.face > 0 ? 1 : -1);
  if (Math.abs(d) < minD) {
    const push = (minD - Math.abs(d)) / 2; let na = a.x - s * push, nb = b.x + s * push; const lo = -sim.half + 0.4, hi = sim.half - 0.4;
    if (na < lo) { nb += lo - na; na = lo; } if (nb > hi) { na -= nb - hi; nb = hi; } if (na > hi) na = hi; if (nb < lo) nb = lo;
    a.x = na; b.x = nb;
  }
}

/* ----------------------------------------------------------- step utama */
export function step(sim, inputs) {
  sim.events = []; const r = sim.round;
  if (r.state === 'matchEnd') { r.t++; return sim; }
  if (r.state === 'intro') { r.t++; if (r.t === 1) emit(sim, { t: 'roundStart', no: r.no }); if (r.t >= RULES.introFrames) { r.state = 'fight'; r.t = 0; emit(sim, { t: 'fight' }); } for (const f of sim.f) { f.face = f.idx === 0 ? 1 : -1; } return sim; }
  if (r.state === 'roundEnd') {
    r.t++; for (const f of sim.f) { f.t++; f.vx *= 0.9; f.x += f.vx / 60; f.x = clamp(f.x, -sim.half + 0.4, sim.half - 0.4); }
    if (r.t >= RULES.endFrames) {
      if (r.wins[0] >= 2 || r.wins[1] >= 2) endMatch(sim, r.wins[0] >= 2 ? 0 : 1, 'rounds');
      else { r.no++; r.sudden = false; r.state = 'intro'; r.t = 0; resetRound(sim); }
    } return sim;
  }
  sim.tick++;
  if (sim.freeze > 0) { sim.freeze--; for (const f of sim.f) f.prev = Object.assign({}, inputs[f.idx] || EMPTY_INPUT); return sim; }
  for (const f of sim.f) updateFighter(sim, f, inputs[f.idx], sim.f[1 - f.idx]);
  updateProjectiles(sim); separate(sim);
  // timer & waktu habis
  if (!sim.training && r.state === 'fight') {
    r.timer--;
    if (r.timer <= 0) {
      const [a, b] = sim.f, pa = a.hp / a.maxHp, pb = b.hp / b.maxHp;
      if (Math.abs(pa - pb) > 0.001) endRound(sim, pa > pb ? 0 : 1, 'time');
      else if (!r.sudden) { r.sudden = true; r.timer = RULES.suddenDeathTime * 60; emit(sim, { t: 'sudden' }); for (const f of sim.f) { f.hp = f.maxHp; } }
      else endRound(sim, sim.rng() < 0.5 ? 0 : 1, 'coinflip');
    }
  } else if (sim.training) { for (const f of sim.f) { if (f.state === 'idle') { f.hp = Math.min(f.maxHp, f.hp + 2); f.meter = Math.min(100, f.meter + 0.1); } } }
  return sim;
}
// snapshot ringkas: dipakai renderer lokal DAN dikirim server ke klien online
export function snapshot(sim) {
  return {
    tick: sim.tick, stage: sim.stage, half: sim.half, ev: sim.events, freeze: sim.freeze,
    round: { state: sim.round.state, no: sim.round.no, wins: sim.round.wins, t: sim.round.t, timer: sim.round.timer, sudden: sim.round.sudden, winner: sim.round.winner, matchWinner: sim.round.matchWinner, reason: sim.round.reason },
    f: sim.f.map((f) => ({ idx: f.idx, name: f.name, char: f.charKey, weapon: f.weaponName, x: f.x, y: f.y, face: f.face, hp: f.hp, maxHp: f.maxHp, state: f.state, t: f.t, mv: f.move ? f.move.id : null, mvLen: f.move ? f.move.s + f.move.a + f.move.r : 0, mvS: f.move ? f.move.s : 0, sk: f.skillId || null, skLen: f.skill ? (f.skill.s + (f.skill.rec || 0)) : 0, stamina: f.stamina, meter: f.meter, cd: f.cd, cdMax: { s1: 1, s2: 1, ws: 1 }, shield: f.shield, charge: f.charge, crouch: f.crouch, counterWin: f.counterWin, slow: f.slowF > 0, buff: !!f.buff, invuln: f.invuln })),
    proj: sim.projectiles.map((p) => ({ id: p.id, x: p.x, y: p.y, c: p.color, vx: p.vx })), traps: sim.traps.map((t) => ({ id: t.id, x: t.x, c: t.color })), result: sim.result,
  };
}
