// Klien jaringan: hanya mengirim input; menerima snapshot dari server (server authoritative).
export class Net {
  constructor() { this.ws = null; this.status = 'offline'; this.ping = 0; this.on = {}; this.idx = 0; this.seq = 0; }
  connect(url) {
    return new Promise((res, rej) => {
      try { this.ws = new WebSocket(url); } catch (e) { return rej(e); }
      const to = setTimeout(() => { try { this.ws.close(); } catch (e) {} rej(new Error('Timeout')); }, 6000); this.status = 'connecting';
      this.ws.onopen = () => { clearTimeout(to); this.status = 'online'; this.pinger = setInterval(() => this.send({ t: 'ping', c: performance.now() }), 2000); res(); };
      this.ws.onerror = () => { clearTimeout(to); this.status = 'offline'; rej(new Error('Gagal terhubung ke server')); };
      this.ws.onclose = () => { this.status = 'offline'; clearInterval(this.pinger); this.on.close && this.on.close(); };
      this.ws.onmessage = (ev) => { let m; try { m = JSON.parse(ev.data); } catch (e) { return; } if (m.t === 'pong') this.ping = Math.round(performance.now() - m.c); this.on[m.t] && this.on[m.t](m); };
    });
  }
  send(o) { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(o)); }
  sendInput(i) { this.send({ t: 'input', i }); }
  close() { try { this.ws && this.ws.close(); } catch (e) {} clearInterval(this.pinger); this.status = 'offline'; }
}
