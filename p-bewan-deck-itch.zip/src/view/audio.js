// Audio sintetis WebAudio (tanpa file). Harus dimulai setelah interaksi pengguna.
export const Audio = (() => {
  let ctx = null, master, music, sfx, musicNodes = [], vol = { master: 0.8, music: 0.5, sfx: 0.9 }, timer = null;
  const ensure = () => { if (ctx) return true; try { ctx = new (window.AudioContext || window.webkitAudioContext)(); master = ctx.createGain(); music = ctx.createGain(); sfx = ctx.createGain(); music.connect(master); sfx.connect(master); master.connect(ctx.destination); apply(); return true; } catch (e) { return false; } };
  const apply = () => { if (!ctx) return; master.gain.value = vol.master; music.gain.value = vol.music * 0.35; sfx.gain.value = vol.sfx; };
  const noise = (d) => { const b = ctx.createBuffer(1, ctx.sampleRate * d, ctx.sampleRate), a = b.getChannelData(0); for (let i = 0; i < a.length; i++) a[i] = Math.random() * 2 - 1; const s = ctx.createBufferSource(); s.buffer = b; return s; };
  const env = (g, t, a, d, peak) => { g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.001, t + a + d); };
  function tone(type, f0, f1, dur, peak = 0.4, dest = sfx) { const t = ctx.currentTime, o = ctx.createOscillator(), g = ctx.createGain(); o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur); env(g, t, 0.005, dur, peak); o.connect(g); g.connect(dest); o.start(t); o.stop(t + dur + 0.05); }
  function hiss(dur, f0, f1, peak = 0.3, q = 1) { const t = ctx.currentTime, n = noise(dur), fl = ctx.createBiquadFilter(), g = ctx.createGain(); fl.type = 'bandpass'; fl.Q.value = q; fl.frequency.setValueAtTime(f0, t); fl.frequency.exponentialRampToValueAtTime(f1, t + dur); env(g, t, 0.01, dur, peak); n.connect(fl); fl.connect(g); g.connect(sfx); n.start(t); }
  const W = { Greatsword: [260, 90, 0.34], 'War Axe': [320, 110, 0.3], Spear: [1800, 900, 0.14], Bow: [900, 300, 0.16], 'Dual Daggers': [3200, 1800, 0.09], 'Twin Blades': [2800, 1400, 0.12], Katana: [2400, 800, 0.16], Longsword: [1600, 500, 0.2], Scythe: [500, 150, 0.3] };
  const play = {
    swing(w) { const p = W[w] || W.Longsword; hiss(p[2], p[0], p[1], 0.22, 2); },
    hit(e) { tone('sine', e.heavy ? 150 : 220, 45, e.heavy ? 0.28 : 0.16, 0.7); hiss(0.1, 3000, 400, e.heavy ? 0.5 : 0.3); if (e.weapon === 'Greatsword' || e.weapon === 'War Axe') tone('square', 90, 40, 0.2, 0.25); },
    block() { tone('square', 900, 700, 0.1, 0.25); hiss(0.08, 5000, 2500, 0.25, 6); },
    parry() { tone('triangle', 1500, 2400, 0.25, 0.4); tone('sine', 3000, 3200, 0.3, 0.2); },
    dodge() { hiss(0.2, 800, 2500, 0.15, 0.7); }, dash() { hiss(0.14, 600, 2200, 0.15, 0.7); }, perfectDodge() { tone('sine', 700, 1800, 0.35, 0.35); },
    jump() { tone('sine', 200, 420, 0.1, 0.12); }, land() { tone('sine', 90, 50, 0.1, 0.25); hiss(0.06, 500, 200, 0.15); },
    skill() { tone('sawtooth', 200, 800, 0.35, 0.3); hiss(0.35, 400, 3000, 0.2); }, ult() { tone('sawtooth', 80, 640, 0.8, 0.4); tone('square', 160, 1280, 0.8, 0.2); hiss(0.8, 200, 4000, 0.3); },
    shoot() { hiss(0.12, 1200, 400, 0.2, 3); tone('triangle', 500, 150, 0.1, 0.2); }, knockdown() { tone('sine', 110, 40, 0.3, 0.6); hiss(0.2, 800, 150, 0.3); }, getup() { hiss(0.2, 300, 900, 0.1); },
    guardBreak() { tone('square', 400, 80, 0.4, 0.5); hiss(0.3, 3000, 300, 0.4); }, stun() { tone('sine', 880, 660, 0.25, 0.2); },
    roundStart() { tone('triangle', 330, 330, 0.18, 0.4); setTimeout(() => ctx && tone('triangle', 440, 440, 0.18, 0.4), 220); setTimeout(() => ctx && tone('triangle', 660, 660, 0.4, 0.5), 440); }, fight() { tone('sawtooth', 220, 440, 0.4, 0.5); hiss(0.3, 500, 3000, 0.3); },
    roundEnd() { tone('triangle', 520, 260, 0.6, 0.4); }, victory() { [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => ctx && tone('triangle', f, f, 0.35, 0.4), i * 140)); }, defeat() { [392, 330, 262, 196].forEach((f, i) => setTimeout(() => ctx && tone('sawtooth', f, f * 0.95, 0.4, 0.25), i * 200)); },
    click() { tone('square', 700, 500, 0.05, 0.15); }, confirm() { tone('triangle', 600, 900, 0.12, 0.25); }, back() { tone('triangle', 500, 300, 0.1, 0.2); },
  };
  const MUS = { minor: [110, 130.8, 164.8], taiko: [98, 98, 146.8], airy: [196, 246.9, 293.7], drums: [82.4, 98, 123.5], calm: [174.6, 220, 261.6], storm: [73.4, 87.3, 110], menu: [110, 138.6, 164.8] };
  return {
    vol, ensure, apply, set(k, v) { vol[k] = v; apply(); },
    sfx(name, arg) { if (!ensure() || !play[name]) return; if (ctx.state === 'suspended') ctx.resume(); try { play[name](arg); } catch (e) {} },
    music(kind) {
      if (!ensure()) return; this.stop(); const notes = MUS[kind] || MUS.menu; let i = 0;
      const beat = () => { if (!ctx) return; const f = notes[i++ % notes.length]; const t = ctx.currentTime; const o = ctx.createOscillator(), g = ctx.createGain(), fl = ctx.createBiquadFilter(); o.type = 'sawtooth'; o.frequency.value = f; fl.type = 'lowpass'; fl.frequency.value = 500; env(g, t, 0.3, 1.6, 0.5); o.connect(fl); fl.connect(g); g.connect(music); o.start(t); o.stop(t + 2.2); if (kind === 'taiko' || kind === 'drums' || kind === 'storm') { const t2 = ctx.createOscillator(), g2 = ctx.createGain(); t2.type = 'sine'; t2.frequency.setValueAtTime(110, t); t2.frequency.exponentialRampToValueAtTime(40, t + 0.2); env(g2, t, 0.005, 0.25, 0.8); t2.connect(g2); g2.connect(music); t2.start(t); t2.stop(t + 0.3); } };
      beat(); timer = setInterval(beat, 1800);
    },
    stop() { if (timer) clearInterval(timer); timer = null; },
  };
})();
