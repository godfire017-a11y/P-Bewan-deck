// RENDER: Three.js. Membaca snapshot() saja (tidak pernah mengubah sim). Cocok untuk lokal dan online.
import * as THREE from 'three';
import { FBXLoader } from 'three/addons/loaders/FBXLoader.js';
import * as SkeletonUtils from 'three/addons/utils/SkeletonUtils.js';
import { CHARACTERS, WEAPONS, STAGES } from '../data/data.js';

const mats = new Map();
const mat = (c, o = {}) => { const k = c + JSON.stringify(o); if (!mats.has(k)) mats.set(k, new THREE.MeshStandardMaterial(Object.assign({ color: c, roughness: 0.7, metalness: 0.2 }, o))); return mats.get(k); };
const box = (w, h, d, m) => new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
const cyl = (r0, r1, h, m, seg = 8) => new THREE.Mesh(new THREE.CylinderGeometry(r0, r1, h, seg), m);

/* ------------------------------------------------------------------ senjata prosedural (dipegang di tangan, ujung ke +Y lokal) */
const STEEL = () => mat(0xc8d0dc, { metalness: 0.9, roughness: 0.3 }), DARK = () => mat(0x2a2024), GOLD = () => mat(0xb08a3a, { metalness: 0.8, roughness: 0.4 });
export function buildWeapon(name) {
  const g = new THREE.Group();
  const blade = (len, w, col) => { const b = box(w, len, 0.03, mat(col || 0xdfe6f0, { metalness: 0.9, roughness: 0.25 })); b.position.y = 0.12 + len / 2; return b; };
  const grip = (len = 0.22) => { const b = cyl(0.025, 0.025, len, DARK()); b.position.y = len / 2 - 0.05; return b; };
  switch (name) {
    case 'Longsword': g.add(grip(), blade(1.0, 0.07), (() => { const c = box(0.28, 0.04, 0.05, GOLD()); c.position.y = 0.12; return c; })()); break;
    case 'Katana': { g.add(grip(0.3), blade(0.95, 0.045, 0xf2f6ff)); const t = cyl(0.06, 0.06, 0.02, DARK(), 12); t.position.y = 0.13; t.rotation.x = Math.PI / 2; g.add(t); break; }
    case 'Greatsword': { g.add(grip(0.4), blade(1.5, 0.16, 0x7a63c9), (() => { const c = box(0.5, 0.06, 0.07, GOLD()); c.position.y = 0.16; return c; })()); break; }
    case 'Spear': { const s = cyl(0.025, 0.025, 2.2, mat(0x6b4a2a)); s.position.y = 0.6; const t = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.4, 6), STEEL()); t.position.y = 1.9; g.add(s, t); break; }
    case 'War Axe': { const s = cyl(0.03, 0.03, 1.1, mat(0x5a3a22)); s.position.y = 0.4; const h = box(0.42, 0.34, 0.05, STEEL()); h.position.set(0.2, 0.95, 0); const h2 = box(0.1, 0.4, 0.06, STEEL()); h2.position.set(0, 0.95, 0); g.add(s, h, h2); break; }
    case 'Dual Daggers': case 'Twin Blades': { const n = name === 'Twin Blades' ? 0.6 : 0.38; g.add(grip(0.18), blade(n, 0.05, name === 'Twin Blades' ? 0x7fe9ff : 0xcfe8cf)); break; }
    case 'Bow': { const curve = new THREE.CatmullRomCurve3([new THREE.Vector3(0, -0.8, 0), new THREE.Vector3(0.25, -0.4, 0), new THREE.Vector3(0.3, 0, 0), new THREE.Vector3(0.25, 0.4, 0), new THREE.Vector3(0, 0.8, 0)]); const b = new THREE.Mesh(new THREE.TubeGeometry(curve, 16, 0.03, 6), mat(0x6b4a2a)); const s = cyl(0.006, 0.006, 1.6, mat(0xeeeeee), 3); g.add(b, s); g.userData.string = s; g.rotation.z = 0; break; }
    case 'Scythe': { const s = cyl(0.03, 0.03, 1.8, mat(0x3a3040)); s.position.y = 0.6; const b = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.04, 6, 14, Math.PI * 0.8), mat(0xb9ff8a, { emissive: 0x335522 })); b.position.set(0.4, 1.5, 0); b.rotation.z = Math.PI * 0.6; g.add(s, b); break; }
    default: g.add(grip(), blade(0.9, 0.06));
  }
  return g;
}
// model GLB asli (opsional): dimuat async; bila gagal, pakai prosedural. Dimensi dinormalisasi ke panjang target.
const glbCache = new Map(); let GLTFLoaderP = null;
export async function loadWeaponGLB(name, targetLen) {
  const w = WEAPONS[name]; if (!w || !w.model) return null;
  try {
    GLTFLoaderP = GLTFLoaderP || import('three/addons/loaders/GLTFLoader.js');
    const { GLTFLoader } = await GLTFLoaderP;
    if (!glbCache.has(w.model)) glbCache.set(w.model, await new GLTFLoader().loadAsync(`assets/models/${w.model}.glb`));
    const src = glbCache.get(w.model).scene.clone(true); const b = new THREE.Box3().setFromObject(src), s = b.getSize(new THREE.Vector3());
    const k = targetLen / Math.max(s.x, s.y, s.z); src.scale.multiplyScalar(k); const b2 = new THREE.Box3().setFromObject(src), c = b2.getCenter(new THREE.Vector3());
    // panjang terpanjang diarahkan ke +Y, pangkal di origin
    const wrap = new THREE.Group(); src.position.sub(c); wrap.add(src); const sz = b2.getSize(new THREE.Vector3());
    if (sz.x >= sz.y && sz.x >= sz.z) wrap.rotation.z = Math.PI / 2; else if (sz.z >= sz.y && sz.z >= sz.x) wrap.rotation.x = Math.PI / 2;
    const out = new THREE.Group(); out.add(wrap); wrap.position.y = targetLen * 0.45; return out;
  } catch (e) { return null; }
}

/* ------------------------------------------------------------------ fighter prosedural (rig sederhana) */
class ProcRig {
  constructor(color, scale = 1) {
    this.root = new THREE.Group(); const body = mat(color, { roughness: 0.6 }), skin = mat(0xd6b08c), dark = mat(0x1a1a22);
    this.hips = new THREE.Group(); this.hips.position.y = 0.95; this.root.add(this.hips);
    this.torso = new THREE.Group(); this.torso.position.y = 0.1; this.hips.add(this.torso);
    const tm = box(0.5, 0.65, 0.3, body); tm.position.y = 0.33; this.torso.add(tm);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.17, 12, 10), skin); head.position.y = 0.85; this.torso.add(head); this.head = head;
    const hair = box(0.36, 0.1, 0.34, dark); hair.position.y = 0.96; this.torso.add(hair);
    const mkLimb = (len, w, m, x, y) => { const p = new THREE.Group(); p.position.set(x, y, 0); const l = box(w, len, w, m); l.position.y = -len / 2; p.add(l); return p; };
    this.armR = mkLimb(0.6, 0.13, body, 0.33, 0.6); this.armL = mkLimb(0.6, 0.13, body, -0.33, 0.6); this.torso.add(this.armR, this.armL);
    this.handR = new THREE.Group(); this.handR.position.y = -0.62; this.armR.add(this.handR); this.handL = new THREE.Group(); this.handL.position.y = -0.62; this.armL.add(this.handL);
    this.legR = mkLimb(0.95, 0.16, dark, 0.14, 0); this.legL = mkLimb(0.95, 0.16, dark, -0.14, 0); this.hips.add(this.legR, this.legL);
    this.root.scale.setScalar(scale); this.root.rotation.y = Math.PI / 2;     // lokal +Z = depan -> +X dunia
  }
  pose(S, t, speed) {
    const f = S, st = f.state, p = f.mvLen ? Math.min(1, f.t / f.mvLen) : 0, w = Math.sin(t * 9);
    let hy = 0.95, lean = 0, aR = 0, aL = 0, lR = 0, lL = 0, roll = 0, tw = 0;
    const idle = Math.sin(t * 2.2) * 0.02;
    switch (st) {
      case 'idle': hy += idle; aR = -0.3; aL = -0.5; break;
      case 'walk': lR = w * 0.6; lL = -w * 0.6; aR = -w * 0.5 - 0.2; aL = w * 0.5 - 0.3; lean = 0.1; break;
      case 'crouch': hy = 0.6; lR = -0.6; lL = 0.6; aR = -0.4; aL = -0.5; break;
      case 'jump': lR = -0.5; lL = 0.4; aR = -1.2; aL = -1.0; break;
      case 'guard': aR = -1.5; aL = -1.6; lean = -0.1; hy = f.crouch ? 0.65 : 0.92; break;
      case 'blockstun': aR = -1.5; aL = -1.6; lean = -0.2; break;
      case 'attack': case 'charge': {
        if (f.char && WEAPONS[f.weapon].ranged) { aL = -1.5; aR = -1.4 - (f.charge / 60) * 0.3; lean = 0.1; tw = 0.3; }
        else { const sw = p < 0.3 ? -2.4 * (p / 0.3) : -2.4 + 3.4 * Math.min(1, (p - 0.3) / 0.25); aR = f.mv === 'H' || f.mv === 'L3' ? sw : sw * 0.7 - 0.8; aL = -0.6; lean = 0.25 * Math.sin(p * Math.PI); tw = -0.4 * Math.sin(p * Math.PI); lR = 0.3; lL = -0.4; if (f.mv === 'LAUNCH' || f.mv === 'CROUCH' || f.mv === 'LOW') hy = 0.7; }
        break; }
      case 'skill': { const q = f.skLen ? f.t / f.skLen : 0; aR = -2.2 + q * 3; aL = -1.8 + q * 2; lean = 0.2; break; }
      case 'dash': lean = 0.4; lR = 0.7; lL = -0.7; aR = 0.5; aL = 0.5; break;
      case 'dodge': lean = -0.3; hy = 0.7; lR = 0.4; lL = -0.4; break;
      case 'hitstun': lean = -0.45; aR = 0.5; aL = 0.6; tw = 0.2; break;
      case 'parried': lean = -0.3; aR = -2.6; aL = -0.3; break;
      case 'knockdown': case 'dead': roll = Math.min(1, f.t / 10); hy = 0.25 + (1 - roll) * 0.7; break;
      case 'getup': roll = Math.max(0, 1 - f.t / 24); hy = 0.4 + 0.55 * (1 - roll); break;
      case 'victory': aR = -2.8 + Math.sin(t * 6) * 0.2; aL = -2.6; break;
    }
    this.hips.position.y += (hy - this.hips.position.y) * 0.4; this.torso.rotation.z = -lean; this.torso.rotation.y = tw;
    this.armR.rotation.z = -aR; this.armL.rotation.z = -aL; this.legR.rotation.z = lR; this.legL.rotation.z = lL;
    this.hips.rotation.z = roll * -Math.PI / 2 * (f.face < 0 ? -1 : 1) * 0 + roll * -1.45;
    this.root.visible = true;
  }
}

/* ------------------------------------------------------------------ golem asli (prototipe) untuk TITAN */
const golem = { tried: false, ok: false, template: null, clips: {}, upFix: false, loading: null };
async function fetchBuf(url) { const r = await fetch(url); if (!r.ok) throw new Error(url + ' ' + r.status); const raw = new Uint8Array(await r.arrayBuffer()); const bin = atob(new TextDecoder().decode(raw)); const b = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i); return await new Response(new Blob([b]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer(); }
export function loadGolem(onProgress) {
  if (golem.loading) return golem.loading;
  golem.loading = (async () => {
    try {
      const names = ['model', 'idle', 'walk', 'atk1', 'atk2', 'atk3', 'hit', 'death']; const loader = new FBXLoader(); let n = 0;
      const bufs = await Promise.all(names.map(async (k) => { const b = await fetchBuf(`assets/${k}.txt`); onProgress && onProgress(++n / names.length); return b; }));
      const parsed = {}; names.forEach((k, i) => { parsed[k] = loader.parse(bufs[i], ''); });
      golem.template = parsed.model; for (const k of names.slice(1)) { const c = parsed[k].animations && parsed[k].animations[0]; if (!c) throw new Error('klip kosong ' + k); c.name = k; golem.clips[k] = c; }
      // buang root-motion supaya posisi dikontrol sim
      const idle = golem.clips.idle, ref = {}; let best = null, bm = -1, vAxis = 1;
      const depth = (o) => { let d = 0; for (let p = o.parent; p; p = p.parent) if (p.isBone) d++; return d; };
      for (const t of idle.tracks) { if (!t.name.endsWith('.position')) continue; const nm = t.name.slice(0, -9), o = golem.template.getObjectByName(nm); if (!o || !o.isBone || depth(o) > 1) continue; const v = [t.values[0], t.values[1], t.values[2]]; ref[nm] = v; const mg = Math.hypot(...v); if (mg > bm) { bm = mg; best = nm; vAxis = v.map(Math.abs).indexOf(Math.max(...v.map(Math.abs))); } }
      for (const c of Object.values(golem.clips)) for (const t of c.tracks) { if (!t.name.endsWith('.position')) continue; const nm = t.name.slice(0, -9), r = ref[nm]; if (!r) continue; const keep = nm === best ? vAxis : -1; for (let i = 0; i < t.values.length; i += 3) for (let a = 0; a < 3; a++) if (a !== keep) t.values[i + a] = r[a]; }
      golem.template.updateMatrixWorld(true); const sz = new THREE.Box3().setFromObject(golem.template).getSize(new THREE.Vector3()); golem.upFix = sz.z > sz.y * 1.4; golem.ok = true;
    } catch (e) { console.warn('Golem gagal dimuat, pakai model prosedural:', e); golem.ok = false; }
    return golem.ok;
  })();
  return golem.loading;
}
const CLIP_FOR = (S) => { switch (S.state) { case 'walk': return ['walk', 1]; case 'attack': case 'charge': return [S.mv === 'L1' || S.mv === 'L2' ? 'atk1' : S.mv === 'H' ? 'atk2' : 'atk3', 1]; case 'skill': case 'dash': return ['atk3', 1]; case 'hitstun': case 'blockstun': case 'parried': return ['hit', 1]; case 'knockdown': case 'dead': return ['death', 1]; default: return ['idle', 1]; } };
class GolemRig {
  constructor(height) {
    this.root = new THREE.Group(); this.holder = new THREE.Group(); this.root.add(this.holder); this.model = SkeletonUtils.clone(golem.template); this.holder.add(this.model);
    this.model.traverse((o) => { if (o.isMesh) { o.frustumCulled = false; } });
    this.model.rotation.set(golem.upFix ? -Math.PI / 2 : 0, 0, 0); this.root.updateMatrixWorld(true);
    let b = new THREE.Box3().setFromObject(this.model, true); const s = b.getSize(new THREE.Vector3()); const k = height / Math.max(0.0001, s.y); this.model.scale.setScalar(k); this.root.updateMatrixWorld(true);
    b = new THREE.Box3().setFromObject(this.model, true); const c = b.getCenter(new THREE.Vector3()); this.model.position.set(-c.x, -b.min.y, -c.z);
    this.mixer = new THREE.AnimationMixer(this.model); this.actions = {}; this.cur = null;
    for (const [k2, clip] of Object.entries(golem.clips)) { const a = this.mixer.clipAction(clip); if (k2 === 'idle' || k2 === 'walk') a.setLoop(THREE.LoopRepeat, Infinity); else { a.setLoop(THREE.LoopOnce, 1); a.clampWhenFinished = true; } this.actions[k2] = a; }
    this.play('idle'); this.handR = new THREE.Group(); this.handL = new THREE.Group(); this.torso = this.head = new THREE.Group(); this.armR = this.armL = new THREE.Group();
  }
  play(n, ts = 1) { const a = this.actions[n]; if (!a) return; if (this.cur === a) { if (n === 'idle' || n === 'walk') return; } a.reset(); a.enabled = true; a.setEffectiveTimeScale(ts); if (this.cur && this.cur !== a) this.cur.crossFadeTo(a, 0.12, false); a.play(); this.cur = a; }
  pose(S, t, dt, flip) {
    const [clip] = CLIP_FOR(S); if (this.lastKey !== clip + S.state + S.mv) { this.lastKey = clip + S.state + S.mv; this.play(clip, S.state === 'attack' ? 1.6 : 1); }
    this.mixer.update(dt); this.holder.rotation.y = Math.PI / 2 + (flip ? Math.PI : 0);
  }
}

/* ------------------------------------------------------------------ VFX pool */
class Pool {
  constructor(scene, n, make) { this.items = []; for (let i = 0; i < n; i++) { const m = make(); m.visible = false; scene.add(m); this.items.push({ m, life: 0, max: 1, vel: new THREE.Vector3(), grow: 0 }); } this.i = 0; }
  spawn(pos, life, color, scale = 1, vel, grow = 0) { const it = this.items[this.i++ % this.items.length]; it.m.visible = true; it.m.position.copy(pos); it.m.scale.setScalar(scale); it.m.material.color.setHex(color); it.m.material.opacity = 1; it.life = it.max = life; it.vel.copy(vel || new THREE.Vector3()); it.grow = grow; return it; }
  update(dt) { for (const it of this.items) { if (!it.m.visible) continue; it.life -= dt; if (it.life <= 0) { it.m.visible = false; continue; } it.m.position.addScaledVector(it.vel, dt); it.m.scale.addScalar(it.grow * dt); it.m.material.opacity = it.life / it.max; } }
}

/* ------------------------------------------------------------------ dunia */
export class World {
  constructor(canvasHost) {
    this.host = canvasHost; this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
    this.quality = 1; this.setScale(Math.min(devicePixelRatio || 1, 1.5)); this.renderer.outputColorSpace = THREE.SRGBColorSpace; canvasHost.prepend(this.renderer.domElement);
    this.scene = new THREE.Scene(); this.camera = new THREE.PerspectiveCamera(32, 16 / 9, 0.1, 200); this.shake = 0; this.cam = { x: 0, z: 14 };
    this.hemi = new THREE.HemisphereLight(0xaab8d8, 0x202028, 1.0); this.key = new THREE.DirectionalLight(0xffffff, 1.6); this.key.position.set(3, 8, 9); this.rimL = new THREE.DirectionalLight(0xaec4ff, 1.8); this.rimL.position.set(-4, 5, -7); this.scene.add(this.hemi, this.key, this.rimL);
    this.stageGroup = new THREE.Group(); this.scene.add(this.stageGroup); this.views = []; this.t = 0; this.flip = false; this.particles = [];
    const sp = new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    this.sparks = new Pool(this.scene, 48, () => new THREE.Mesh(new THREE.SphereGeometry(0.06, 5, 4), sp.clone()));
    this.flashes = new Pool(this.scene, 8, () => new THREE.Mesh(new THREE.SphereGeometry(0.4, 8, 6), sp.clone()));
    this.rings = new Pool(this.scene, 10, () => { const m = new THREE.Mesh(new THREE.RingGeometry(0.8, 1, 24), sp.clone()); m.material.side = THREE.DoubleSide; m.rotation.x = -Math.PI / 2; return m; });
    this.slashes = new Pool(this.scene, 8, () => { const m = new THREE.Mesh(new THREE.RingGeometry(0.7, 1, 20, 1, 0, Math.PI * 0.7), sp.clone()); m.material.side = THREE.DoubleSide; return m; });
    this.projMeshes = new Map(); this.trapMeshes = new Map();
    this.shadowTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d'); const r = g.createRadialGradient(32, 32, 0, 32, 32, 32); r.addColorStop(0, 'rgba(0,0,0,.7)'); r.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = r; g.fillRect(0, 0, 64, 64); return new THREE.CanvasTexture(c); })();
    this.resize();
  }
  setScale(s) { this.renderer.setPixelRatio(s); this.scale = s; }
  resize() { const w = this.host.clientWidth || innerWidth, h = this.host.clientHeight || innerHeight; this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix(); }
  setStage(key) {
    const st = STAGES[key]; this.stageKey = key; while (this.stageGroup.children.length) { const o = this.stageGroup.children.pop(); o.traverse((x) => { if (x.geometry) x.geometry.dispose(); }); }
    const c = document.createElement('canvas'); c.width = 4; c.height = 256; const g = c.getContext('2d'), gr = g.createLinearGradient(0, 0, 0, 256), hex = (n) => '#' + n.toString(16).padStart(6, '0');
    gr.addColorStop(0, hex(st.sky[0])); gr.addColorStop(0.55, hex(st.sky[1])); gr.addColorStop(1, hex(st.sky[2])); g.fillStyle = gr; g.fillRect(0, 0, 4, 256); const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; this.scene.background = tex; this.scene.fog = new THREE.FogExp2(st.fog, 0.035);
    this.hemi.color.setHex(st.light); this.key.color.setHex(st.light); this.rimL.color.setHex(st.rim);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(80, 40), mat(st.ground, { roughness: 1, metalness: 0 })); ground.rotation.x = -Math.PI / 2; ground.position.z = -8; this.stageGroup.add(ground);
    const edge = mat(st.rim, { emissive: st.rim, emissiveIntensity: 0.6 }); for (const s of [-1, 1]) { const e = box(0.15, 0.6, 3, edge); e.position.set(s * (st.width + 0.2), 0.3, 0); this.stageGroup.add(e); }   // batas arena jelas
    let sd = key.length * 77; const rnd = () => (sd = (sd * 16807) % 2147483647) / 2147483647;
    const deco = mat(new THREE.Color(st.fog).multiplyScalar(0.55).getHex(), { roughness: 1, metalness: 0 });
    for (let i = 0; i < 40; i++) { const h = 6 + rnd() * 14, w = 0.6 + rnd() * 1.4; const m = key === 'frozenRuins' ? new THREE.Mesh(new THREE.ConeGeometry(w, h, 5), deco) : box(w, h, w, deco); m.position.set((rnd() - 0.5) * 60, h / 2 - 0.3, -6 - rnd() * 26); this.stageGroup.add(m); }
    if (key === 'crimsonDojo' || key === 'shadowTemple') for (let i = -2; i <= 2; i++) { const l = new THREE.Mesh(new THREE.SphereGeometry(0.3, 8, 6), new THREE.MeshBasicMaterial({ color: key === 'crimsonDojo' ? 0xff7a40 : 0x8fd3ff })); l.position.set(i * 4.5, 3.2, -3); this.stageGroup.add(l); }
    const moon = new THREE.Mesh(new THREE.CircleGeometry(4, 24), new THREE.MeshBasicMaterial({ color: st.rim, transparent: true, opacity: 0.18, fog: false })); moon.position.set(5, 9, -40); this.stageGroup.add(moon);
    // partikel lingkungan (sedikit, satu draw call)
    const N = 90, pos = new Float32Array(N * 3); for (let i = 0; i < N; i++) { pos[i * 3] = (rnd() - 0.5) * 24; pos[i * 3 + 1] = rnd() * 7; pos[i * 3 + 2] = -4 + rnd() * 6; }
    const pg = new THREE.BufferGeometry(); pg.setAttribute('position', new THREE.BufferAttribute(pos, 3)); const pts = new THREE.Points(pg, new THREE.PointsMaterial({ size: st.particles === 'rain' ? 0.04 : 0.09, color: st.rim, transparent: true, opacity: 0.7, depthWrite: false })); pts.userData = { kind: st.particles }; this.stageGroup.add(pts); this.env = pts;
  }
  clearFighters() { for (const v of this.views) this.scene.remove(v.group); this.views = []; }
  addFighter(f) {
    const ch = CHARACTERS[f.char]; const group = new THREE.Group(); let rig, isGolem = false;
    if (f.char === 'TITAN' && golem.ok) { rig = new GolemRig(2.9); isGolem = true; } else rig = new ProcRig(ch.color, f.char === 'TITAN' ? 1.25 : f.char === 'STARK' ? 0.95 : 1);
    group.add(rig.root); const sh = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 1.2), new THREE.MeshBasicMaterial({ map: this.shadowTex, transparent: true, depthWrite: false })); sh.rotation.x = -Math.PI / 2; sh.position.y = 0.02; group.add(sh);
    const aura = new THREE.Mesh(new THREE.SphereGeometry(1.1, 12, 10), new THREE.MeshBasicMaterial({ color: 0x88ccff, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending })); aura.position.y = 1; group.add(aura);
    this.scene.add(group); const v = { group, rig, isGolem, weaponKey: null, wGroups: [], aura, idx: f.idx, char: f.char, flash: 0, ghost: 0, prevHp: f.hp, trail: null }; this.views.push(v); this.setWeapon(v, f.weapon); return v;
  }
  async setWeapon(v, name) {
    if (v.weaponKey === name) return; v.weaponKey = name; for (const g of v.wGroups) g.parent && g.parent.remove(g); v.wGroups = []; const w = WEAPONS[name], rig = v.rig;
    const place = (group, hand, rot) => { group.rotation.set(0, 0, rot); hand.add(group); v.wGroups.push(group); };
    const mk = () => buildWeapon(name);
    if (v.isGolem) { const hand = new THREE.Group(); hand.position.set(1.3, 1.6, 0.6); v.group.add(hand); v.handFixed = hand; const g = mk(); g.scale.setScalar(2); hand.add(g); v.wGroups.push(hand); return; }
    if (w.hand === 'R') place(mk(), rig.handR, 0); else if (w.hand === 'L') { place(mk(), rig.handL, 0); } else { place(mk(), rig.handR, 0); place(mk(), rig.handL, 0); }
    if (w.model) { const g = await loadWeaponGLB(name, w.grip === 'bow' ? 1.6 : 1.3); if (g && v.weaponKey === name) { for (const o of v.wGroups) o.visible = false; const hand = w.hand === 'L' ? rig.handL : rig.handR; hand.add(g); v.wGroups.push(g); } }
  }
  fx(e, S) {
    const P = (x, y) => new THREE.Vector3(x, y, 0.4), V = (x, y, z) => new THREE.Vector3(x, y, z);
    switch (e.t) {
      case 'hit': { const col = e.armor ? 0xffffff : 0xffc060; this.flashes.spawn(P(e.x, e.y), 0.1, 0xffffff, e.heavy ? 1.6 : 1, null, 4); const n = this.quality > 0.6 ? (e.heavy ? 9 : 5) : 3; for (let i = 0; i < n; i++) this.sparks.spawn(P(e.x, e.y), 0.3, col, 1, V((Math.random() - 0.4) * 6 * (e.dir || 1), Math.random() * 4, (Math.random() - 0.5) * 2)); this.shake = Math.max(this.shake, e.heavy ? 0.35 : 0.14); break; }
      case 'block': for (let i = 0; i < 4; i++) this.sparks.spawn(P(e.x, e.y), 0.25, 0x9fd3ff, 1, V((Math.random() - 0.5) * 5, Math.random() * 3, 0)); break;
      case 'parry': this.flashes.spawn(P(e.x, e.y), 0.2, 0xffffaa, 1.4, null, 5); this.rings.spawn(V(e.x, e.y, 0.4), 0.3, 0xffffaa, 0.4, null, 6); this.shake = Math.max(this.shake, 0.2); break;
      case 'perfectDodge': this.rings.spawn(V(e.x, 0.05, 0), 0.5, 0x66ffff, 0.6, null, 5); this.views[e.f].ghost = 0.6; break;
      case 'dodge': case 'dash': this.views[e.f].ghost = 0.3; break;
      case 'land': this.rings.spawn(V(e.x, 0.05, 0), 0.3, 0xcccccc, 0.3, null, 3); break;
      case 'knockdown': this.rings.spawn(V(e.x, 0.05, 0), 0.4, 0xdddddd, 0.4, null, 5); this.shake = Math.max(this.shake, 0.25); break;
      case 'area': this.rings.spawn(V(e.x, 0.05, 0), 0.5, e.color, 0.4, null, e.r * 4); this.shake = Math.max(this.shake, 0.4); break;
      case 'teleport': this.flashes.spawn(P(e.x, e.y), 0.25, 0xb070ff, 1.5, null, 3); break;
      case 'guardBreak': case 'stun': this.rings.spawn(V(e.x, e.y + 0.4, 0.4), 0.5, 0xffe040, 0.3, null, 3); break;
      case 'swing': { const v = this.views[e.f], f = S.f[e.f], w = WEAPONS[e.weapon]; if (!w) break; const ang = e.move === 'LAUNCH' ? 0.9 : e.move === 'HIGH' ? 0.4 : e.move === 'CROUCH' ? -0.5 : (Math.random() - 0.5) * 0.4; const it = this.slashes.spawn(V(f.x + f.face * 0.8, f.y + 1.1, 0.5), 0.16, w.trail || 0xffffff, w.reach * 0.9, null, 2); it.m.rotation.set(0, 0, ang + (f.face < 0 ? Math.PI : 0)); break; }
      case 'telegraph': if (e.ult) this.shake = Math.max(this.shake, 0.15); this.views[e.f].telegraph = e; break;
    }
  }
  render(S, dt, flip, shakeOn = true) {
    this.t += dt; const [a, b] = S.f;
    for (const v of this.views) {
      const f = S.f[v.idx], gx = f.x; v.group.position.set(gx, f.y, 0);
      if (v.isGolem) { v.rig.pose(f, this.t, dt, flip); v.rig.root.rotation.y = f.face > 0 ? 0 : Math.PI; }
      else { v.rig.pose(f, this.t, dt); v.rig.root.rotation.y = f.face > 0 ? Math.PI / 2 : -Math.PI / 2; }
      if (f.hp < v.prevHp) v.flash = 1; v.prevHp = f.hp;
      v.rig.root.traverse && null; const flashAmt = Math.max(v.flash, v.telegraph ? 0.4 : 0); v.aura.material.opacity = Math.max(0, v.ghost * 0.4) + (f.shield > 0 ? 0.25 : 0) + (f.buff ? 0.15 : 0) + (v.flash * 0.2);
      v.aura.material.color.setHex(f.shield > 0 ? 0xcccccc : f.buff ? 0xff4040 : v.ghost > 0 ? 0x66ffff : 0xffaa66); v.flash = Math.max(0, v.flash - dt * 4); v.ghost = Math.max(0, v.ghost - dt); if (v.telegraph && f.state !== 'skill') v.telegraph = null;
      // posisi tangan untuk golem (tidak ada attachment tulang yang tervalidasi): senjata mengikuti sisi depan
      if (v.handFixed) { v.handFixed.position.set(f.face * 1.3, 1.5 + (f.state === 'attack' ? 0.5 : 0), 0.4); v.handFixed.rotation.z = -f.face * (f.state === 'attack' ? 1.2 : 0.3); }
    }
    // proyektil
    const seen = new Set(); for (const p of S.proj) { seen.add(p.id); let m = this.projMeshes.get(p.id); if (!m) { m = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.6, 5), new THREE.MeshBasicMaterial({ color: p.c })); m.rotation.z = -Math.PI / 2; this.scene.add(m); this.projMeshes.set(p.id, m); } m.position.set(p.x, p.y, 0.3); m.scale.x = p.vx < 0 ? -1 : 1; if (Math.random() < 0.5) this.sparks.spawn(new THREE.Vector3(p.x, p.y, 0.3), 0.2, p.c, 0.8); }
    for (const [id, m] of this.projMeshes) if (!seen.has(id)) { this.scene.remove(m); m.geometry.dispose(); m.material.dispose(); this.projMeshes.delete(id); }
    const seenT = new Set(); for (const t of S.traps) { seenT.add(t.id); let m = this.trapMeshes.get(t.id); if (!m) { m = new THREE.Mesh(new THREE.RingGeometry(0.4, 0.6, 16), new THREE.MeshBasicMaterial({ color: t.c, side: THREE.DoubleSide })); m.rotation.x = -Math.PI / 2; this.scene.add(m); this.trapMeshes.set(t.id, m); } m.position.set(t.x, 0.05, 0); m.rotation.z += dt; }
    for (const [id, m] of this.trapMeshes) if (!seenT.has(id)) { this.scene.remove(m); m.geometry.dispose(); m.material.dispose(); this.trapMeshes.delete(id); }
    this.sparks.update(dt); this.flashes.update(dt); this.rings.update(dt); this.slashes.update(dt);
    // partikel lingkungan
    if (this.env) { const pos = this.env.geometry.attributes.position, k = this.env.userData.kind, sp = k === 'rain' ? 14 : k === 'snow' ? 0.8 : k === 'embers' || k === 'fireflies' ? -0.5 : 0.2; for (let i = 0; i < pos.count; i++) { let y = pos.getY(i) - sp * dt; if (k === 'embers' || k === 'fireflies' || k === 'dust') y = pos.getY(i) + Math.sin(this.t + i) * 0.003 + 0.2 * dt; if (y < 0) y = 7; if (y > 7) y = 0; pos.setY(i, y); pos.setX(i, pos.getX(i) + Math.sin(this.t * 0.5 + i) * 0.003); } pos.needsUpdate = true; }
    // kamera
    const mid = (a.x + b.x) / 2, dist = Math.abs(a.x - b.x), vt = Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2)), halfW = Math.max(this.halfMin || 5.2, dist / 2 + 3.4), z = Math.max(halfW / (vt * this.camera.aspect), 2.6 / vt + 1), k = 1 - Math.pow(0.001, dt);
    this.cam.x += (mid - this.cam.x) * k; this.cam.z += (z - this.cam.z) * k; this.shake = Math.max(0, this.shake - dt * 1.8); const sh = shakeOn ? this.shake : 0;
    this.camera.position.set(this.cam.x + (Math.random() - 0.5) * sh * 0.3, 1.9 + (Math.random() - 0.5) * sh * 0.3, this.cam.z); this.camera.lookAt(this.cam.x, 1.3, 0);
    this.renderer.render(this.scene, this.camera);
  }
  // pratinjau karakter+senjata (menu): kamera menyorot satu fighter
  renderPreview(S, dt, flip) { this.render(S, dt, flip, false); }
}
export { golem };
