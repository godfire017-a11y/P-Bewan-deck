# P Bewan Deck — Laporan Audit & Status

## 1. Audit prototipe (golem-duel.zip)
- `index.html` memakai Three.js 0.160 dari CDN jsDelivr + FBXLoader. File `assets/*.txt` BUKAN teks biasa: isinya FBX biner yang di-gzip lalu di-base64 (8 file: model, idle, walk, atk1-3, hit, death). Semua berhasil didekode ke "Kaydara FBX Binary".
- Prototipe membuang root-motion, memperbaiki orientasi Z-up otomatis, dan punya tombol "Balik arah model". Semua dipertahankan (render.js `loadGolem`, Settings > Balik arah model Golem).
- `animations.zip` berisi 24 FBX Golem tambahan (attack1-5, dodge, gethit1-3, death1-3, jog/walk 4 arah, idle1-4, turn180). BELUM dipakai: build saat ini memakai 7 klip prototipe.
- `mesh.zip`: model Golem FBX/OBJ bertipe per bagian (armor, hammer, shield). Belum dipakai.

## 2. Audit aset GLB (dibaca langsung dari header glTF)
| Aset | Tris | Skeleton | Animasi | Catatan |
|---|---|---|---|---|
| phantom_assassin | 8.9k | 76 joint | 100+ klip (idle, run, attack1-4, crit, death, victory, stun, teleport) | Paling lengkap. 28 MB, berat untuk entry-level. Belum dipasang. |
| bull_knight | 61k | 89 joint | 1 klip 7.3 dtk ("Take 001") | Harus dipotong per segmen; 61k tris terlalu berat tanpa LOD. Belum dipasang. |
| orc_warrior | 9k | 83 joint | 1 klip 2 dtk | Satu siklus saja. Belum dipasang. |
| vampire-female | 50k | 102 joint | Hanya T-pose (1 keyframe) | Tidak punya animasi; butuh animasi prosedural/retarget. |
| archer (shooting arrow) | 21k | 68 joint | 1 klip 5.8 dtk | Hanya panahan. |
| bow | 1.9k | 10 joint | 0.33 dtk | DIPAKAI sebagai model Bow (dinormalisasi). |
| voidfang_greatsword | 22k | - | - | DIPAKAI sebagai Greatsword. |
| fantasy_axe_and_shield | 10k | 8 joint | wiggle | DIPAKAI sebagai War Axe (kapak + perisai satu mesh; belum dipisah). |
| soul_reaper_scythe | 19k | - | 1 | Senjata tambahan "Scythe" (belum dipasang ke karakter). |
| revolver, evil_pistol, daedric_gauntlet | - | - | - | Tidak dipakai: senjata api/sarung tangan di luar roster senjata brief. |
| undead-grave-knight, argent | - | - | - | Hanya FBX di dalam ZIP, tanpa animasi; belum diperiksa lebih lanjut. |

Pemetaan karakter-ke-aset (usulan saya, bisa Anda ubah di `data.js`): TITAN=Stone Golem, STARK=Phantom Assassin, MASHU=Orc, ZUKI=Bull Knight, APCB=Vampire, TONY=Archer.

## 3. Status per tahap
| Tahap | Status |
|---|---|
| 1 Audit | Selesai (dokumen ini) |
| 2-3 Arena, movement, serangan, defense, hit detection | Logika SELESAI dan diuji di Node (`npm test`). Tampilan belum diuji di browser. |
| 4 Combo, skill, ultimate, senjata | Logika selesai + diuji; 8 senjata + 1 tambahan, 6 karakter x (2 skill + ult + pasif) |
| 5 Character/Weapon/Stage select | Kode selesai, BELUM dijalankan di browser |
| 6 PvE (6 mode, 7 gaya AI, boss 3 fase) | Selesai di kode; AI diuji lewat simulasi |
| 7 Tiga ronde, surrender, rematch | Selesai + diuji di Node |
| 8 PvP lokal + online | Lokal: kode ada, perlu keyboard untuk P2. Online: server + klien ditulis, diuji dengan socket tiruan SAJA |
| 9 Audio/VFX/UI/settings | Kode selesai; audio sintetis (tanpa file). Belum didengar/dilihat di perangkat |
| 10 Pengujian | Hanya otomatis (Node). Pengujian perangkat belum dilakukan |

## 4. Hasil tes otomatis
- `npm test`: 100 lulus. Cakupan: power budget 100 poin, kelengkapan data, moveset unik tiap senjata, 180 match AI vs AI semua pasangan karakter selesai tanpa NaN/di luar arena, maks 3 ronde, tidak ada stun-lock panjang, 26 kombinasi karakter+senjata, jangkauan hit, guard, serangan rendah menembus guard berdiri, Bow dari jauh, surrender, sudden death.
- `node tests/net.test.js`: 12 lulus (matchmaking, sanitasi input, disconnect/reconnect, surrender dan rematch oleh server) memakai socket tiruan.

## 5. Balance (AI vs AI, senjata default, 180 match)
ZUKI 58%, MASHU 48%, TITAN 52%, STARK 28%, APCB 75%, TONY 38%.
Lolos batas tes (20-80%) tetapi BELUM seimbang: APCB terlalu kuat, STARK terlalu lemah. Ini hasil AI, bukan pemain manusia; angka bisa berbeda saat dimainkan. Tuning ada di `src/data/data.js`.

## 6. Bug / keterbatasan yang diketahui
1. Tampilan belum pernah dijalankan di browser. Kemungkinan ada bug render/UI yang belum ketahuan.
2. Karakter selain TITAN memakai model prosedural (kotak-kotak). GLB Phantom/Orc/Bull/Vampire/Archer belum dipasang karena animasinya tidak sesuai kebutuhan (lihat tabel).
3. Senjata Golem (TITAN) mengikuti posisi tetap, bukan tulang tangan (tulang tangan Golem belum divalidasi).
4. Model senjata GLB di tangan prosedural: orientasi/ukuran diperkirakan otomatis dan perlu dikalibrasi visual.
5. Three.js dimuat dari CDN (internet diperlukan). Mode offline mandiri belum ada karena saya tidak punya akses jaringan untuk mengunduh library. Taruh `three.module.js` + addons di folder lokal dan ubah importmap.
6. Tidak ada build single-file HTML (butuh bundler + jaringan).
7. Online: tanpa client-side prediction (terasa delay sebesar ping); snapshot 30 Hz. Belum diuji dua perangkat nyata.
8. Survival: HP terbawa hanya ke awal ronde 1 lawan berikutnya.
9. Daily Challenge: modifier `armor`/`swift` ada di data tetapi hanya sebagian yang diterapkan di sim (`dmg`, `hp`, `noUlt`, `enemyDef`, `spd`).
10. Performa pada Android entry-level BELUM diukur. Ada resolusi adaptif dan efek terbatas, tetapi tidak ada jaminan 30/60 FPS. GLB berat (28 MB Phantom) belum dioptimasi.
11. Lisensi aset (Dota Phantom Assassin, Skyrim fanart, dll.) perlu Anda periksa sebelum publikasi.

## 7. Checklist pengujian (centang saat Anda uji di perangkat)
- [ ] Game terbuka tanpa error | [ ] Pilih karakter & senjata | [ ] Senjata di tangan berganti saat preview
- [ ] Gerak/lompat/nunduk/dash/dodge | [ ] Hit konsisten | [ ] Kombo berbeda tiap senjata
- [ ] Skill & ultimate | [ ] AI menyerang/bertahan | [ ] PvE tidak monoton | [ ] Pilih arena
- [ ] Maks 3 ronde | [ ] Surrender & rematch | [ ] Audio on/off | [ ] UI nyaman landscape | [ ] PvP dua klien

## 8. Perbaikan loading / UI (itch.io, Android)
**Bug nyata yang ditemukan dan diperbaiki**
1. CSS: `.col{display:flex}` menimpa `.screen{display:none}` sehingga Stage/PvE/PvP/Settings/About selalu tampil menumpuk di atas loading (terbukti lewat reproduksi di Chromium). Kini hanya `.screen.on` yang tampil, dengan layer z-index tetap.
2. Pemuatan Three.js dari CDN tanpa penanganan error: bila modul gagal, layar macet di "Memuat…" tanpa pesan.
3. Import map lokal memakai path tanpa `./` (tidak valid, diabaikan browser) sehingga jalur `lib/three` pasti gagal.
4. `main.js` tidak pernah mengirim sinyal "siap" ke bootstrap, sehingga error apa pun setelah menu (atau penjaga 30 detik) bisa memunculkan layar error. Sekarang sinyal dikirim setelah frame render pertama sukses.
5. Error di dalam `boot()` (mis. WebGL gagal dibuat) hanya mengganti teks loading; sekarang ditampilkan sebagai layar error lengkap.
6. Menu/Join Room kini tidak bisa tampil sebelum engine siap (guard `engineReady`), satu state UI aktif: loading, error, mainMenu, select, stage, pve, multiplayer, joinRoom, lobby, settings, about, fight.
7. Join Room dipisah dari Multiplayer; ada layar Lobby; koneksi tidak dianggap sukses sebelum server membalas (timeout 6 dtk); tombol Back selalu ke menu utama.

**Yang BELUM bisa dipastikan:** error persis di perangkat Anda (Android Chrome, itch.io) tidak bisa saya reproduksi karena Three.js asli tidak tersedia di lingkungan saya (tanpa internet). Dengan Three.js tiruan, game sampai menu. Build baru menampilkan error asli lengkap bila masih gagal.
